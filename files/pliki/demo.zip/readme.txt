DEMO GRY "POLANIE CD"
--------------------------

OPIS:
Aplikacja ta jest wersj� demonstracyjn� gry POLANIE CD. Zawarte w niej zosta�o sze�� misji, po jednej z ka�dej kampanii. Niestety z przyczyn czysto technicznych, w demie nie mo�na w��czy� g�osu. Niech fakt ten b�dzie kolejnym powodem przemawiaj�cym za zdobyciem pe�nej, p�ytowej wersji Polan.

SPOS�B INSTALACJI:
Demo gry Polanie pochodzi z p�yty pewnego pisma. Do zainstalowania tej wersji, a p�niej tak�e do grania w ni�, normalnie potrzebna jest p�ytka. W sumie pliki spakowane w "demo.zip" mo�naby by�o nagra� na p�ytk� i zainstalowa� z niej. Szkoda jednak marnowa� ca�ej p�ytki na pare MB danych. Dlatego przedstawi� teraz spos�b na uruchomienie tego dema z dysku. U�yte przeze mnie nazwy katalog�w i partycji s� tylko moimi propozycjami, dzia�aj�cymi w przypadku mojego komputera. Mo�ecie jed dowolnie zmienia�, je�eli tylko b�dzie to dla Was wygodniejsze. 

Wszystkie niezb�dne czynno�ci wypunktowa�em poni�ej:

1. Tworzymy katalog o nazwie "Virtual" na dysku "D:". W tym katalogu tworzymy podkatalog "Demo".
2. Przegrywamy do niego ca�� zawarto�� pliku "demo.zip" (4 MB po rozpakowaniu).
3. Uruchamiamy "Tryb MS-DOS".
4. W linii polece� wpisujemy polecenie "SUBST G: D:\VIRTUAL\DEMO", gdzie litera "G:" jest pierwsz� woln� liter� po ostatnim z CD-ROM�w. Przyk�adowo, je�eli Tw�j CD-ROM ma literk� "E:", to tutaj wpisujesz "F:"; natomiast fragment "D:\VIRTUAL\DEMO" oznacza �cie�k� dost�pu do katalogu, w kt�rym znajduj� si� pliki przegrane w punkcie numer 2.
5. Uruchamiaj�c teraz "Eksplorator Windows" zauwa�ymy, �e "dosz�a" nam jedna partycja - w tym przypadku "G:" - o etykiecie identycznej z etykiet� partycji "D:".
6. Klikamy na literze "G:". Po prawej stronie pojawi nam si� lista plik�w zawartych w katalogu "D:\VIRTUAL\DEMO" - zupe�nie jakby�my nagrali oddzieln� z nimi p�ytk�! Uruchamiamy wi�c plik "Instaluj.exe" na dysku "G:" i instalujemy najzwyczajniej w �wiecie demo. Po poprawnym zainstalowaniu gry (na przyk�ad w katalogu "D:\POLANIE") uruchamiamy Setup i konfigurujemy kart� d�wi�kow� pami�taj�c o wy��czeniu muzyki, gdy� i tak nie b�dzie ona dost�pna bez p�yty. Mo�emy teraz bez kompaktu z Polanami uruchomi� jej demo. Je�eli koniecznie chcemy mie� muzyk�, mo�emy w�o�y� dowoln� p�ytk� do czytnika i w��czy� odtwarzanie utworu, tak samo jak by�my chcieli pos�ucha� muzyki.

Uwaga!
Po zrestartowaniu komputera utworzona poprzednio partycja "G:" zniknie i demo gry Polanie nie b�d� dzia�a�. Mo�emy j� odtworzy� uruchamiaj�c wcze�niej u�yte polecenie "SUBST G: D:\VIRTUAL". Proponuj� jednak u�atwi� sobie ca�� t� operacj� pisz�c plik wsadowy "start.bat", automatycznie tworz�cy now� "partycj�" i uruchamiaj�cy Polan. Taki w�a�nie plik zawar�em w pliku, kt�ry �ci�gn��e�. Nale�y go skopiowa� do katalogu z Polanami i od tej pory zawsze odpala� nim gr�. Zauwa�, �e plik ten zosta� stworzony w postaci stosownej dla mojego przypadku. Je�eli wi�c z jakich� przyczyn zmieni�e� zaproponowane przez mnie nazwy katalog�w czy partycji, to musisz r�cznie wyedytowa� plik i zmieni� stosowne fragmenty.

To chyba wszystkie informacje potrzebne do skutecznego u�ywania tego dema. Je�eli masz jeszcze jakie� w�tpliwo�ci lub czego� nie rozumiesz, napisz. S�u�� pomoc�!

--------------------------
DOKUMENTACJ� OPRACOWA�:
Janusz "Swoosh" Prokulewicz
jprokulewicz@poczta.onet.pl
www.polanie.prv.pl