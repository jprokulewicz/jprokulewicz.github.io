NOWE MISJE DO GRY POLANIE, AUTOR: KRZYSZTOF FORNALSKI
----------------------------------------------------------

SPOS�B INSTALACJI:
Rozpakuj pliki "level.dat" oraz "level.ini" do podkatalogu "GRAF", znajduj�cego si� w katalogu g��wnym gry POLANIE. I... tyle. Zauwa�, �e plik zawieraj�cy oryginalne mapy zostanie skasowany, wi�c najlepiej zrobi� na dysku drug� kopi� ca�ych Polan, by mie� w ka�dej chwili dost�p do pierwotnej wersji.

ZMIANY W TEJ WERSJI:
- autor zmieni� ka�d� z 25 map zawartych w grze,
- poszczeg�lne mapki r�ni� si� w znacznym stopniu od ich "oryginalnych" poprzednik�w, ale zauwa�y� mo�na niezmienione fragmenty,
- autor nie zmienia� cel�w poszczeg�lnych misji, czyli je�eli przyk�adowo w danej misji mieli�my doprowadzi� posta� specjaln� do jakiego� miejsca, to tutaj tak�e b�dziemy musieli to zrobi�,
- mapki by�y testowane i da si� przej�� ka�d� z nich, je�eli jednak wychwycisz jaki� b��d lub masz jakie� inne uwagi to skontaktuj si� bezp�rednio z autorem (mail:krzysztof_fornalski@poczta.onet.pl) lub wy�lij maila do autora strony www.polanie.prv.pl - adres poni�ej.

Mi�ego grania!!


----------------------------------------------------------
DOKUMENTACJ� OPRACOWA�:
Janusz "Swoosh" Prokulewicz
jprokulewicz@poczta.onet.pl
www.polanie.prv.pl