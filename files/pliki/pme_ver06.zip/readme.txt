EDYTOR MISJI DO GRY "POLANIE", ver 0.06
--------------------------------------------

OPIS:
Edytor ten napisa� autor witryny znajduj�cej si� pod adresem: www.polanie.prv.pl, czyli Janusz "Swoosh" Prokulewicz. To prosty, graficzny edytor do map do dyskietkowej wersji Polan.

SPOS�B INSTALACJI:
Rozpakowa� �ci�gni�te archiwum do katalogu zawieraj�cego gre Polanie w wersji dyskietkowej. W�a�ciwie w obecnej wersji mo�na go rozpakowa� do oddzielnego katalogu i pracowa� "na boku", r�cznie kopiuj�c do "orygina�u" gotowe ju� mapki. Klawiszologi� mo�na podejrze� pod klawiszem F1.

Oto lista rzeczy, kt�re w aktualnej wersji nie dzia�aj� lub nie zosta�y ostatecznie dopracowane:
- zapisywanie mapek dzia�a tylko w tzw. trybie quick-save, czyli nie mo�na zapisa� stworzonej mapki bezpo�rednio do pliku gry Polanie, pod nazw� "Levels,dat"
- podczas zapisywania mapek poprzez quick-save (klawisz F2) NIE s� uwzgl�dniane ustawienia poczynione w menu dost�pnym po klikni�ciu na przycisk "Ustawienia mapy" w prawym dolnym rogu ekranu. Edytor zatem w tej wersji nale�y traktowa� jako pomoc przy tworzeniu mapek, a nie kompleksowe i w pe�ni dzia�aj�ce narz�dzie do tworzenia scenariuszy. W celu stworzenia mapki zalecam utworzy� teren za pomoc� edytora i zapisa� przez F2. Stworzona mapa zostanie zapisana w pliku "quick.dat". Nast�pnie nale�y skopiowa� ten plik i wklei� r�cznie do pliku "Levels.dat". Ustawienia zawarte w pierwszym wierszu ka�dej z mapek nale�y wyedytowa� r�cznie. Znaczenia poszczeg�lnych parametr�w scenariusza s� podane w dziale POLANIE 3.5" -> EDYTOR na wspomnianej wy�ej stronie.

To chyba wszystkie informacje potrzebne do skutecznego pos�ugiwania si� tym edytorem. Je�eli masz jeszcze jakie� w�tpliwo�ci lub czego� nie rozumiesz, napisz. S�u�� pomoc�! Pragn� tak�e poinfromowa�, �e na forum zosta� za�o�ony specjalny w�tek po�wi�cony temu edytorowi - je�eli wi�c macie jakie� uwagi, komentarze czy propozycje, to zapraszam do wpisywania si�. Oczywi�cie zawsze mo�ecie wys�a� maila na podany ni�ej adres e-mail.

Mam jeszcze gor�c� pro�b� do os�b, kt�re postanowi� stworzy� nowe mapki, o przysy�anie ich na wymieniony ni�ej adres e-mail. Z ch�ci� zamieszcz� je na mojej stronie!


-------------------------------------
DOKUMENTACJ� OPRACOWA�:
Janusz "Swoosh" Prokulewicz
jprokulewicz@poczta.onet.pl
www.polanie.prv.pl