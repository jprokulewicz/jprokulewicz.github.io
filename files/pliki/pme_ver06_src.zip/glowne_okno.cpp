#define SZEROKOSC_MAPY 64
#define WYSOKOSC_MAPY 64

/* 
 macierz 64x64 zawierajaca literki
 konstruktor standradowy, drugi z wczytywaniem z pliku
 
        
 
*/

class Glowne_okno {
      char ** matryca;
      Studnia
};

Studnia::Studnia(int wysokosc, int szerokosc){        //tworzy matryce pustych pol o rozmiarze wysokosc x szerokosc
  this->szer = szerokosc;                       //kazde pole matrycy to pole na planszy, domyslnie puste
  this->wys = wysokosc;
  matryca = new Segment*[wysokosc];
  for (int i=0; i<(wysokosc); i++) {
     matryca[i] = new Segment[szerokosc];
  }
  this->zajete = 0;
  //byc moze trzeba bedzie wyzerowac ta macierz linia...
}

