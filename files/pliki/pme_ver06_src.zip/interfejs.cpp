#include "interfejs.h"
#include <allegro.h>
#define PRZYCISKI_OBIEKTOW_OD_GORY 50
#define PRZYCISKI_OBIEKTOW_OD_PRAWEJ 100
#define PRZYCISKI_OBIEKTOW_ODSTEPY_POZIOME 44
#define PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE 40
#define LICZBA_KATEGORII 7
#define WYBRANY_OBIEKT_X 722
#define WYBRANY_OBIEKT_Y 440
#define OBSZAR_GRY_TOP 20
#define OBSZAR_GRY_LEFT 20
#define UST_MAPY_X 690
#define UST_MAPY_Y 540



extern int rozdzielczosc;



Interfejs::Interfejs(void) {
     wybrana_kategoria = 0;
     liczba_kategorii = LICZBA_KATEGORII;
     
     wybrany_element_kategoria = 0;
     wybrany_element_numer = -1;

     
//     liczba_obiektow[] = { 16, 9, 14, 17, 16, 9, 8};
       liczba_obiektow[0] = 16;
       liczba_obiektow[1] = 9;
       liczba_obiektow[2] = 14;
       liczba_obiektow[3] = 17;
       liczba_obiektow[4] = 16;
       liczba_obiektow[5] = 9;              
       liczba_obiektow[6] = 8;
     for (int i = 0; i<liczba_kategorii; i++)ile_schowanych[i] = 0;

/*
     char literki_0[16] = {' ', 'q', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', 's', 't'};
     char literki_1[9] = {'2', '5', '1', '3', '4', '6', '7', '8', 'w'};
     char literki_2[14] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'a', 'b', 'c', 'j', 'd', 'm', 'n'};
     char literki_3[17] = {'H', 'I', 'J', 'L', 'K', 'M', 'r', 'x', 'y', 'z', ':', ';', '9', '0', '<', '>', ','};    
     char literki_4[4] = {'z', 'z', 'z', 'z'}; //tu sie zmienilo
     char literki_5[9] = {'e', 'f', 'g', 'h', 'i', 'k', 'l', 'o', 'p'};
     char literki_6[8] = {'/', '.', '^', '*', '-', '+', '?', '='};
*/

     literki_0[0] = ' '; literki_0[1] = 'q'; literki_0[2] = '�'; literki_0[3] = '�'; literki_0[4] = '�'; literki_0[5] = '�';
     literki_0[6] = '�'; literki_0[7] = '�'; literki_0[8] = '�'; literki_0[9] = '�'; literki_0[10] = '�'; literki_0[11] = '�';
     literki_0[12] = '�'; literki_0[13] = '�'; literki_0[14] = 's'; literki_0[15] = 't';
     
     literki_1[0] = '2'; literki_1[1] = '5'; literki_1[2] = '1'; literki_1[3] = '3'; literki_1[4] = '4'; literki_1[5] = '6';
     literki_1[6] = '7'; literki_1[7] = '8'; literki_1[8] = 'w';
     
     literki_2[0] = 'A'; literki_2[1] = 'B'; literki_2[2] = 'C'; literki_2[3] = 'D'; literki_2[4] = 'E'; literki_2[5] = 'F';
     literki_2[6] = 'G'; literki_2[7] = 'a'; literki_2[8] = 'b'; literki_2[9] = 'c'; literki_2[10] = 'j'; literki_2[11] = 'd';
     literki_2[12] = 'm'; literki_2[13] = 'n';
     
     literki_3[0] = 'H'; literki_3[1] = 'I'; literki_3[2] = 'J'; literki_3[3] = 'L'; literki_3[4] = 'K'; literki_3[5] = 'M';
     literki_3[6] = 'r'; literki_3[7] = 'x'; literki_3[8] = 'y'; literki_3[9] = 'z'; literki_3[10] = ':'; literki_3[11] =  ';';
     literki_3[12] = '9'; literki_3[13] = '0'; literki_3[14] = '<'; literki_3[15] = '>'; literki_3[16] = ',';
     
     literki_4[0] = 'N'; literki_4[1] = 'O'; literki_4[2] = 'P'; literki_4[3] = 'R'; literki_4[4] = 'Q'; literki_4[5] = 'S'; 
     literki_4[6] = 'T'; literki_4[7] = 'U'; literki_4[8] = 'W'; literki_4[9] = 'Z'; literki_4[10] = '#'; literki_4[11] = 'X'; 
     literki_4[12] = 'Y'; literki_4[13] = '"'; literki_4[14] = '%'; literki_4[15] = '&';
     
     literki_5[0] = 'e'; literki_5[1] = 'f'; literki_5[2] = 'g'; literki_5[3] = 'h'; literki_5[4] = 'i'; literki_5[5] = 'k';
     literki_5[6] = 'l'; literki_5[7] = 'o'; literki_5[8] = 'p';
     
     literki_6[0] = '/'; literki_6[1] = '.'; literki_6[2] = '^'; literki_6[3] = '*'; literki_6[4] = '-'; literki_6[5] = '+';
     literki_6[6] = '?'; literki_6[7] = '=';
   

     PALETTE palette;
//     interfejs_bmp[0] = load_bitmap("grafika/inne/interfejs_kategoria.pcx", palette);
     interfejs_bmp[0] = load_bitmap("grafika/interfejs_kategoria.pcx", palette);     
     interfejs_bmp[1] = load_bitmap("grafika/interfejs_tlo_prawe.pcx", palette);          
     interfejs_bmp[2] = load_bitmap("grafika/interfejs_suwak1.pcx", palette);          
     interfejs_bmp[3] = load_bitmap("grafika/interfejs_suwak2.pcx", palette);          
     interfejs_bmp[4] = load_bitmap("grafika/interfejs_tlo_gorne.pcx", palette);
     interfejs_bmp[5] = load_bitmap("grafika/interfejs_tlo_lewe.pcx", palette);
     interfejs_bmp[6] = load_bitmap("grafika/interfejs_tlo_dolne.pcx", palette);

     obiekty_0[0] = load_bitmap("grafika/0_spacja_trawa.pcx", palette);
     obiekty_0[1] = load_bitmap("grafika/0q_sucha_ziemia.pcx", palette);     
     obiekty_0[2] = load_bitmap("grafika/0_I_z_kreska_skaly.pcx", palette);
     obiekty_0[3] = load_bitmap("grafika/0_A_z_dwiema_kropkami_skaly.pcx", palette);
     obiekty_0[4] = load_bitmap("grafika/0_ll_skaly.pcx", palette);
     obiekty_0[5] = load_bitmap("grafika/0_s_z_fajka_skaly.pcx", palette);
     obiekty_0[6] = load_bitmap("grafika/0_U_z_kreska_skaly.pcx", palette);
     obiekty_0[7] = load_bitmap("grafika/0_srodkowa_kropka_skaly.pcx", palette);
     obiekty_0[8] = load_bitmap("grafika/0_O_z_daszkiem_skaly.pcx", palette);
     obiekty_0[9] = load_bitmap("grafika/0_L_z_kreska_skaly.pcx", palette);
     obiekty_0[10] = load_bitmap("grafika/0_E_z_kreska_skaly.pcx", palette);           
     obiekty_0[11] = load_bitmap("grafika/0_przecinek_skaly.pcx", palette);
     obiekty_0[12] = load_bitmap("grafika/0_O_z_kreska_skaly.pcx", palette);
     obiekty_0[13] = load_bitmap("grafika/0_U_z_kwadracikiem_skaly.pcx", palette);
     obiekty_0[14] = load_bitmap("grafika/0s_przejscie_miedzy_skalami.pcx", palette);
     obiekty_0[15] = load_bitmap("grafika/1t_droga.pcx", palette);

     obiekty_1[0] = load_bitmap("grafika/12_most.pcx", palette);
     obiekty_1[1] = load_bitmap("grafika/15_most.pcx", palette);
     obiekty_1[2] = load_bitmap("grafika/11_most.pcx", palette);
     obiekty_1[3] = load_bitmap("grafika/13_most.pcx", palette);
     obiekty_1[4] = load_bitmap("grafika/14_most.pcx", palette);
     obiekty_1[5] = load_bitmap("grafika/16_most.pcx", palette);
     obiekty_1[6] = load_bitmap("grafika/17_most.pcx", palette);
     obiekty_1[7] = load_bitmap("grafika/18_most.pcx", palette);
     obiekty_1[8] = load_bitmap("grafika/1w_woda.pcx", palette);

     obiekty_2[0] = load_bitmap("grafika/2A_drzewo.pcx", palette);          
     obiekty_2[1] = load_bitmap("grafika/2B_drzewo.pcx", palette);
     obiekty_2[2] = load_bitmap("grafika/2C_drzewo.pcx", palette);
     obiekty_2[3] = load_bitmap("grafika/2D_drzewo.pcx", palette);
     obiekty_2[4] = load_bitmap("grafika/2E_drzewo.pcx", palette);        
     obiekty_2[5] = load_bitmap("grafika/2F_drzewo.pcx", palette);
     obiekty_2[6] = load_bitmap("grafika/2G_drzewo_suche.pcx", palette);
     obiekty_2[7] = load_bitmap("grafika/2a_pien.pcx", palette);
     obiekty_2[8] = load_bitmap("grafika/2b_kamienie.pcx", palette);
     obiekty_2[9] = load_bitmap("grafika/2c_kamienie.pcx", palette);         
     obiekty_2[10] = load_bitmap("grafika/2j_kamien_wysoki.pcx", palette);
     obiekty_2[11] = load_bitmap("grafika/2d_kamienie.pcx", palette);
     obiekty_2[12] = load_bitmap("grafika/2m_kamien_duzy.pcx", palette);
     obiekty_2[13] = load_bitmap("grafika/2n_kamienie.pcx", palette);

     obiekty_3[0] = load_bitmap("grafika/3H_budynek_glowny.pcx", palette);     
     obiekty_3[1] = load_bitmap("grafika/3I_obora.pcx", palette);        
     obiekty_3[2] = load_bitmap("grafika/3J_chata_mieszkalna.pcx", palette);
     obiekty_3[3] = load_bitmap("grafika/3L_chata_wojow.pcx", palette);
     obiekty_3[4] = load_bitmap("grafika/3K_dwor_mocy.pcx", palette);
     obiekty_3[5] = load_bitmap("grafika/3M_dwor_rycerza.pcx", palette);
     obiekty_3[6] = load_bitmap("grafika/3r_palisada.pcx", palette);
     obiekty_3[7] = load_bitmap("grafika/3x_krowa.pcx", palette);     
     obiekty_3[8] = load_bitmap("grafika/3y_drwal.pcx", palette);
     obiekty_3[9] = load_bitmap("grafika/3z_mysliwy.pcx", palette);
     obiekty_3[10] = load_bitmap("grafika/3_dwukropek_miecznik.pcx", palette);          
     obiekty_3[11] = load_bitmap("grafika/3_srednik_wlocznik.pcx", palette);   
     obiekty_3[12] = load_bitmap("grafika/39_kaplanka.pcx", palette);
     obiekty_3[13] = load_bitmap("grafika/30_kaplan.pcx", palette);         
     obiekty_3[14] = load_bitmap("grafika/3_znak_mniejszosci_rycerz.pcx", palette);     
     obiekty_3[15] = load_bitmap("grafika/3_znak_wiekszosci_niedzwiedz.pcx", palette);             
     obiekty_3[16] = load_bitmap("grafika/3_przecinek_strzyga.pcx", palette);          

     obiekty_4[0] = load_bitmap("grafika/4N_wrogi_budynek_glowny.pcx", palette);
     obiekty_4[1] = load_bitmap("grafika/4O_wroga_obora.pcx", palette);
     obiekty_4[2] = load_bitmap("grafika/4P_wroga_chata_mieszkalna.pcx", palette);
     obiekty_4[3] = load_bitmap("grafika/4R_wroga_chata_wojow.pcx", palette);
     obiekty_4[4] = load_bitmap("grafika/4Q_wrogi_dwor_mocy.pcx", palette);
     obiekty_4[5] = load_bitmap("grafika/4S_wrogi_dwor_rycerza.pcx", palette);
     obiekty_4[6] = load_bitmap("grafika/4T_wroga_krowa.pcx", palette);
     obiekty_4[7] = load_bitmap("grafika/4U_wrogi_drwal.pcx", palette);
     obiekty_4[8] = load_bitmap("grafika/4W_wrogi_mysliwy.pcx", palette);
     obiekty_4[9] = load_bitmap("grafika/4Z_wrogi_miecznik.pcx", palette);
     obiekty_4[10] = load_bitmap("grafika/4_hasz_wrogi_wlocznik.pcx", palette);
     obiekty_4[11] = load_bitmap("grafika/4X_wroga_kaplanka.pcx", palette);
     obiekty_4[12] = load_bitmap("grafika/4Y_wrogi_kaplan.pcx", palette);
     obiekty_4[13] = load_bitmap("grafika/4_podwojny_cudzyslow_wrogi_rycerz.pcx", palette);
     obiekty_4[14] = load_bitmap("grafika/4_procent_wrogi_niedzwiedz.pcx", palette);
     obiekty_4[15] = load_bitmap("grafika/4_ampersand_wroga_strzyga.pcx", palette);

     obiekty_5[0] = load_bitmap("grafika/5e_tabliczka.pcx", palette);          
     obiekty_5[1] = load_bitmap("grafika/5f_sciezka.pcx", palette);          
     obiekty_5[2] = load_bitmap("grafika/5g_sadzawka.pcx", palette);   
     obiekty_5[3] = load_bitmap("grafika/5h_pal.pcx", palette);
     obiekty_5[4] = load_bitmap("grafika/5i_slupek_z_czaszka.pcx", palette);             
     obiekty_5[5] = load_bitmap("grafika/5k_studnia.pcx", palette);         
     obiekty_5[6] = load_bitmap("grafika/5l_kamienny_stolik_ofiarny.pcx", palette);
     obiekty_5[7] = load_bitmap("grafika/5o_ognisko_male.pcx", palette);     
     obiekty_5[8] = load_bitmap("grafika/5p_ognisko_duze.pcx", palette);        
     
     obiekty_6[0] = load_bitmap("grafika/6_ukosnik_miejsce_przemiany.pcx", palette);
     obiekty_6[1] = load_bitmap("grafika/6_kropka_uzdrowisko.pcx", palette);
     obiekty_6[2] = load_bitmap("grafika/6_daszek_miejsce_docelowe.pcx", palette);
     obiekty_6[3] = load_bitmap("grafika/6_gwiazdka_jednostka_specjalna.pcx", palette);          
     obiekty_6[4] = load_bitmap("grafika/6_minus_pastwisko_wroga.pcx", palette);
     obiekty_6[5] = load_bitmap("grafika/6_plus_odkryty_teren.pcx", palette);             
     obiekty_6[6] = load_bitmap("grafika/6_pytajnik_miejsce_zbiorki.pcx", palette);         
     obiekty_6[7] = load_bitmap("grafika/6_rownosc_miejsce_rozpoczecia_misji.pcx", palette);

     pusty_przycisk = load_bitmap("grafika/interfejs_pusty_przycisk.pcx", palette);
     pusty_przycisk_dlugi = load_bitmap("grafika/interfejs_pusty_przycisk_dlugi.pcx", palette);
     kursory[0] = load_bitmap("grafika/kursory/strzalka_duza.pcx", palette);

     set_mouse_sprite(kursory[0]);     
//     drzewo = load_bitmap("obiekty/drzewo_a.pcx", palette);
//     trawa = load_bitmap("obiekty/trawa.pcx", palette);
}

void Interfejs::wyswietl_interfejs(BITMAP* ekran) {
     for (int i = 0; i<22; i++) {
         for (int j = 0; j<22; j++) {
//         stretch_blit(trawa,ekran,0,0,trawa->w,trawa->h,j*32,i*28,2*trawa->w,2*trawa->h);
         }
     }
/*     masked_stretch_blit(drzewo,ekran,0,0,drzewo->w,drzewo->h,200,200,2*drzewo->w,2*drzewo->h);
     masked_stretch_blit(drzewo,ekran,0,0,drzewo->w,drzewo->h,300,200,2*drzewo->w,2*drzewo->h);
     masked_stretch_blit(drzewo,ekran,0,0,drzewo->w,drzewo->h,250,200,2*drzewo->w,2*drzewo->h);
     masked_stretch_blit(drzewo,ekran,0,0,drzewo->w,drzewo->h,300,300,2*drzewo->w,2*drzewo->h);          
*/     
     if (rozdzielczosc == 0) wyswietl_interfejs_800(ekran);
     if (rozdzielczosc == 1) wyswietl_interfejs_1024(ekran);     
     
//void blit(BITMAP *source, BITMAP *dest, int source_x, int source_y, int dest_x, int dest_y, int width, int height);

//void masked_stretch_blit(BITMAP *source, BITMAP *dest, int source_x, source_y, source_w, source_h,
// int dest_x, dest_y, dest_w, dest_h);     
}

void Interfejs::wyswietl_obiekty(BITMAP* ekran) {
     int i;
     int granica = (liczba_obiektow[wybrana_kategoria]/2);

     switch (wybrana_kategoria) {
        case 0:
          for (i = ile_schowanych[0]; i<granica; i++) {
              stretch_blit(obiekty_0[2*i],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[0]), 36, 32);
              stretch_blit(obiekty_0[2*i+1],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ+PRZYCISKI_OBIEKTOW_ODSTEPY_POZIOME, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[0]), 36, 32);
          }
          if (liczba_obiektow[0]%2 == 1) 
              stretch_blit(obiekty_0[2*(i)],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[0]), 36, 32);
          break;
        case 1:
          for (i = ile_schowanych[1]; i<granica; i++) {
              stretch_blit(obiekty_1[2*i],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[1]), 36, 32);
              stretch_blit(obiekty_1[2*i+1],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ+PRZYCISKI_OBIEKTOW_ODSTEPY_POZIOME, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[1]), 36, 32);
          }
          if (liczba_obiektow[1]%2 == 1) 
              stretch_blit(obiekty_1[2*(i)],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[1]), 36, 32);
          break;
        case 2:
          for (i = ile_schowanych[2]; i<granica; i++) {
              stretch_blit(obiekty_2[2*i],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[2]), 36, 32);
              stretch_blit(obiekty_2[2*i+1],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ+PRZYCISKI_OBIEKTOW_ODSTEPY_POZIOME, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[2]), 36, 32);
          }
          if (liczba_obiektow[2]%2 == 1) 
              stretch_blit(obiekty_2[2*(i)],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[2]), 36, 32);
          break;
        case 3:
          for (i = ile_schowanych[3]; i<granica; i++) {
              stretch_blit(obiekty_3[2*i],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[3]), 36, 32);
              stretch_blit(obiekty_3[2*i+1],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ+PRZYCISKI_OBIEKTOW_ODSTEPY_POZIOME, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[3]), 36, 32);
          }
          if (liczba_obiektow[3]%2 == 1) 
              stretch_blit(obiekty_3[2*(i)],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[3]), 36, 32);
          break;             
        case 4:
          for (i = ile_schowanych[4]; i<granica; i++) {
              stretch_blit(obiekty_4[2*i],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[4]), 36, 32);
              stretch_blit(obiekty_4[2*i+1],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ+PRZYCISKI_OBIEKTOW_ODSTEPY_POZIOME, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[4]), 36, 32);
          }
          if (liczba_obiektow[4]%2 == 1) 
              stretch_blit(obiekty_4[2*(i)],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[4]), 36, 32);
          break;                       
        case 5:
          for (i = ile_schowanych[5]; i<granica; i++) {
              stretch_blit(obiekty_5[2*i],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[5]), 36, 32);
              stretch_blit(obiekty_5[2*i+1],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ+PRZYCISKI_OBIEKTOW_ODSTEPY_POZIOME, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[5]), 36, 32);
          }
          if (liczba_obiektow[5]%2 == 1) 
              stretch_blit(obiekty_5[2*(i)],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[5]), 36, 32);
          break;                       
        case 6:
          for (i = ile_schowanych[6]; i<granica; i++) {
              stretch_blit(obiekty_6[2*i],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[6]), 36, 32);
              stretch_blit(obiekty_6[2*i+1],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ+PRZYCISKI_OBIEKTOW_ODSTEPY_POZIOME, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[6]), 36, 32);
          }
          if (liczba_obiektow[6]%2 == 1) 
              stretch_blit(obiekty_6[2*(i)],ekran,0,0,18, 16, ekran->w-PRZYCISKI_OBIEKTOW_OD_PRAWEJ, PRZYCISKI_OBIEKTOW_OD_GORY+PRZYCISKI_OBIEKTOW_ODSTEPY_PIONOWE*(i-ile_schowanych[6]), 36, 32);
          break;                       
     }
}

void Interfejs::pokaz(void) {
    if (ile_schowanych[wybrana_kategoria]>0) ile_schowanych[wybrana_kategoria]--;
}

void Interfejs::schowaj(void) {
    if (liczba_obiektow[wybrana_kategoria]%2 == 1) {
    if (ile_schowanych[wybrana_kategoria]<liczba_obiektow[wybrana_kategoria]/2) ile_schowanych[wybrana_kategoria]++;
    }
    else {
    if (ile_schowanych[wybrana_kategoria]<liczba_obiektow[wybrana_kategoria]/2-1) ile_schowanych[wybrana_kategoria]++;
    }
}

void Interfejs::zmien_kategorie_prawo(void){
     wybrana_kategoria++;
     wybrana_kategoria %= liczba_kategorii;
}

void Interfejs::zmien_kategorie_lewo(void){
     wybrana_kategoria--;
     if (wybrana_kategoria<0) wybrana_kategoria=liczba_kategorii-1;
}

void Interfejs::wyswietl_interfejs_800(BITMAP* ekran){
     blit(interfejs_bmp[0],ekran,0,0,ekran->w-120, 30,interfejs_bmp[0]->w,interfejs_bmp[0]->h);
     //tlo prawe
     blit(interfejs_bmp[1],ekran,0,0,ekran->w-120, 0,interfejs_bmp[1]->w,interfejs_bmp[1]->h);
     blit(interfejs_bmp[1],ekran,0,0,ekran->w-120, 180,interfejs_bmp[1]->w,interfejs_bmp[1]->h);
     blit(interfejs_bmp[1],ekran,0,0,ekran->w-120, 360,interfejs_bmp[1]->w,interfejs_bmp[1]->h);
     blit(interfejs_bmp[1],ekran,0,0,ekran->w-120, 540,interfejs_bmp[1]->w,60);
     //gorne tlo
     blit(interfejs_bmp[4],ekran,0,0,ekran->w-310, 0,interfejs_bmp[4]->w,interfejs_bmp[4]->h);
     blit(interfejs_bmp[4],ekran,0,0,ekran->w-500, 0,interfejs_bmp[4]->w,interfejs_bmp[4]->h);
     blit(interfejs_bmp[4],ekran,0,0,ekran->w-690, 0,interfejs_bmp[4]->w,interfejs_bmp[4]->h);
     blit(interfejs_bmp[4],ekran,100,0,ekran->w-780, 0,interfejs_bmp[4]->w-100,interfejs_bmp[4]->h);
     //lewe tlo
     blit(interfejs_bmp[5],ekran,0,0,0,0,interfejs_bmp[5]->w,interfejs_bmp[5]->h);
     blit(interfejs_bmp[5],ekran,0,0,0,180,interfejs_bmp[5]->w,interfejs_bmp[5]->h);
     blit(interfejs_bmp[5],ekran,0,0,0,360,interfejs_bmp[5]->w,interfejs_bmp[5]->h);
     blit(interfejs_bmp[5],ekran,0,0,0,540,interfejs_bmp[5]->w,60);
     //dolne tlo
     blit(interfejs_bmp[6],ekran,0,0,20,580,interfejs_bmp[6]->w,interfejs_bmp[6]->h);
     blit(interfejs_bmp[6],ekran,0,0,117,580,interfejs_bmp[6]->w,interfejs_bmp[6]->h);
     blit(interfejs_bmp[6],ekran,0,0,214,580,interfejs_bmp[6]->w,interfejs_bmp[6]->h);
     blit(interfejs_bmp[6],ekran,0,0,311,580,interfejs_bmp[6]->w,interfejs_bmp[6]->h);
     blit(interfejs_bmp[6],ekran,0,0,408,580,interfejs_bmp[6]->w,interfejs_bmp[6]->h);
     blit(interfejs_bmp[6],ekran,0,0,505,580,interfejs_bmp[6]->w,interfejs_bmp[6]->h);
     blit(interfejs_bmp[6],ekran,0,0,602,580,78,interfejs_bmp[6]->h);
//void masked_blit(BITMAP *source, BITMAP *dest, int source_x, int source_y, int dest_x, int dest_y, int width, int height);

//void blit(BITMAP *source, BITMAP *dest, int source_x, int source_y, int dest_x, int dest_y, int width, int height);

     //przycisk - ust_mapy
     masked_stretch_blit(pusty_przycisk_dlugi,ekran,0,0,50, 16, UST_MAPY_X, UST_MAPY_Y, 100, 32);
     
     textout_centre(ekran, font, "USTAWIENIA", UST_MAPY_X+50, UST_MAPY_Y+5, 65000);
     textout_centre(ekran, font, "MAPY", UST_MAPY_X+50, UST_MAPY_Y+18, 65000);

     masked_blit(interfejs_bmp[2],ekran,0,0,ekran->w-104, 20,interfejs_bmp[2]->w,interfejs_bmp[2]->h);//suwak1
     blit(interfejs_bmp[3],ekran,0,0,ekran->w-88+wybrana_kategoria*8, 24,interfejs_bmp[3]->w,interfejs_bmp[3]->h);//suwak2
     
     wyswietl_obiekty(ekran);


}

void Interfejs::wyswietl_interfejs_1024(BITMAP* ekran){}

void Interfejs::wyswietl_wybrany_obiekt(BITMAP* ekran){
     if (wybrany_element_numer > -1)
       switch (wybrany_element_kategoria) {
              case 0:
                   stretch_blit(obiekty_0[wybrany_element_numer],ekran,0,0,18, 16, WYBRANY_OBIEKT_X, WYBRANY_OBIEKT_Y, 36, 32);
                   break;
              case 1:
                   stretch_blit(obiekty_1[wybrany_element_numer],ekran,0,0,18, 16, WYBRANY_OBIEKT_X, WYBRANY_OBIEKT_Y, 36, 32);
                   break;
              case 2:
                   stretch_blit(obiekty_2[wybrany_element_numer],ekran,0,0,18, 16, WYBRANY_OBIEKT_X, WYBRANY_OBIEKT_Y, 36, 32);
                   break;
              case 3:
                   stretch_blit(obiekty_3[wybrany_element_numer],ekran,0,0,18, 16, WYBRANY_OBIEKT_X, WYBRANY_OBIEKT_Y, 36, 32);
                   break;
              case 4:
                   stretch_blit(obiekty_4[wybrany_element_numer],ekran,0,0,18, 16, WYBRANY_OBIEKT_X, WYBRANY_OBIEKT_Y, 36, 32);
                   break;
              case 5:
                   stretch_blit(obiekty_5[wybrany_element_numer],ekran,0,0,18, 16, WYBRANY_OBIEKT_X, WYBRANY_OBIEKT_Y, 36, 32);
                   break;
              case 6:
                   stretch_blit(obiekty_6[wybrany_element_numer],ekran,0,0,18, 16, WYBRANY_OBIEKT_X, WYBRANY_OBIEKT_Y, 36, 32);
                   break;
       }
     else masked_stretch_blit(pusty_przycisk,ekran,0,0,18, 16, WYBRANY_OBIEKT_X, WYBRANY_OBIEKT_Y, 36, 32);
}

void Interfejs::wybierz_obiekt(int numer_ikonki){
     //nr ikonki 0-15, ew. -1 dla braku wybranego elementu
     if (numer_ikonki < liczba_obiektow[wybrana_kategoria]) {
        wybrany_element_kategoria = wybrana_kategoria;
        wybrany_element_numer = numer_ikonki;
     }
//     else
//        wybrany_element_numer = -1;
}

void Interfejs::wybierz_kategorie(int nr_kategorii){
     wybrana_kategoria = nr_kategorii;
}

char Interfejs::literka_wybranego_obiektu(void){
    switch(wybrany_element_kategoria) {
         case 0: return literki_0[wybrany_element_numer];
         case 1: return literki_1[wybrany_element_numer];
         case 2: return literki_2[wybrany_element_numer];
         case 3: return literki_3[wybrany_element_numer];
         case 4: return literki_4[wybrany_element_numer];
         case 5: return literki_5[wybrany_element_numer];
         case 6: return literki_6[wybrany_element_numer];
    }
}


