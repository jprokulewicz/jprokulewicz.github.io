#define LICZBA_KATEGORII 7
#include <allegro.h>

class Interfejs {
      int wybrana_kategoria;
      int liczba_kategorii;
      int ile_schowanych[LICZBA_KATEGORII];
      BITMAP* interfejs_bmp[10];
      BITMAP* obiekty_0[16];
      BITMAP* obiekty_1[9];
      BITMAP* obiekty_2[14];
      BITMAP* obiekty_3[17];      
      BITMAP* obiekty_4[16];      
      BITMAP* obiekty_5[9];
      BITMAP* obiekty_6[8];
      int liczba_obiektow[LICZBA_KATEGORII];
      BITMAP* kursory[2];
      BITMAP* pusty_przycisk;
      BITMAP* pusty_przycisk_dlugi;
      
      int wybrany_element_kategoria;
      int wybrany_element_numer;

      char literki_0[16];
      char literki_1[9];
      char literki_2[14];
      char literki_3[17];
      char literki_4[16];
      char literki_5[9];
      char literki_6[8];
                  
public:
     Interfejs(void); 
     void wyswietl_interfejs(BITMAP* ekran);
     void wyswietl_interfejs_800(BITMAP* ekran);
     void wyswietl_interfejs_1024(BITMAP* ekran);
     void wyswietl_obiekty(BITMAP* ekran);
     void schowaj(void);
     void pokaz(void);
     void zmien_kategorie_prawo(void);
     void zmien_kategorie_lewo(void);
     void wybierz_kategorie(int nr_kategorii);
     void wybierz_obiekt(int numer_ikonki);
     void wyswietl_wybrany_obiekt(BITMAP* ekran);       //obiekt, ktory wybralismy do wstawiania
     char literka_wybranego_obiektu(void);
};


