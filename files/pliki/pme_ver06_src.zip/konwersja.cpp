#define BUFSIZE 7
#include <stdio.h>
#include "konwersja.h"
//konwertuje int na char*, maksymalny int = 9999
char* intToChar (int dana) {
      static char wynik[BUFSIZE];
//      for (int i=0; i<BUFSIZE; i++) wynik[i] = '0';
      for (int i=BUFSIZE-2; i>=0; i--) {
          wynik[i] = 48 + dana % 10;
          dana = dana / 10;
      }
      wynik[BUFSIZE-1] = '\0';
      int i=0;
      while(wynik[i]=='0') i++;
      if (wynik[i] == '\0') {
                   return &wynik[i-1];}
      return &wynik[i];
}
/*
main() {
       printf("%s\n", intToChar(2534));
       printf("%s\n", intToChar(34));
       printf("%s\n", intToChar(0));
       printf("%s\n", intToChar(34));
       printf("%s\n", intToChar(5555));              
}
*/


//getline kopiuje do char* caly wiersz i zwraca wskaznik do poczatku tablicy
/*#define MAKSYMALNA_DL_LINII 100
char* getline(FILE* plik) {
      static char wynik[MAKSYMALNA_DL_LINII];
      int i = 0;
      int znak = '\0';
      while (i < MAKSYMALNA_DL_LINII-1 && znak != '\n' && znak != EOF) {
            wynik[i] = getc(plik);
            i++;
      }
      wynik[i] = '\n';
      return wynik;
}
*/

void kopiuj_plik(char* plik_wej, char* plik_wyj) {
     int c;
     FILE *wej, *wyj;
     
     wej = fopen(plik_wej, "r");
     wyj = fopen(plik_wyj, "w");
     
     while ((c = fgetc(wej)) != EOF)
           fputc(c, wyj);
     fclose(wej);
     fclose(wyj);
}

