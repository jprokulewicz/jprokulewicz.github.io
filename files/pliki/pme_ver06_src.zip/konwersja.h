char* intToChar (int dana);
//char* getline(FILE* plik); //nietestowana
void kopiuj_plik(char* plik_wej, char* plik_wyj);

