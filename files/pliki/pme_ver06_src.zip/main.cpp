#define PRZYCISKI_OBIEKTOW_OD_GORY 50
#define PRZYCISKI_OBIEKTOW_OD_PRAWEJ 100
#define OBSZAR_GRY_TOP 20
#define OBSZAR_GRY_LEFT 20


#include <string.h>
#include <allegro.h>
#include "tryb_grafiki.h"
#include "interfejs.h"
#include "obszar_edycji.h"
#include "konwersja.h"
#include "menu_misji.h"
#include "menu_pomocy.h"
//#include <rycerz.cpp>


int rozdzielczosc;     //0 dla 800, 1 dla 1024
int tryb1 = 1;
int akcja1 = 0;
int akcja2 = 0;

int main()
{ 
 // Initialize Allegro.        
 allegro_init();
 set_color_depth(16); 
 set_window_title("Polanie Map Editor, ver 0.05"); 
 Tryb_grafiki * p_tryb_grafiki = NULL;
 p_tryb_grafiki = new Tryb_grafiki(0, 1);
 rozdzielczosc = p_tryb_grafiki->ustawiony_tryb();
 
 Obszar_edycji * p_obszar_edycji = NULL;
 p_obszar_edycji = new Obszar_edycji(64,64);


  BITMAP * buffer;
  buffer=create_bitmap(p_tryb_grafiki->zwroc_ekran_width(), p_tryb_grafiki->zwroc_ekran_height()); 

  Interfejs* p_interfejs = NULL;
  p_interfejs = new Interfejs();

  Menu_misji* p_menu_misji = NULL;
  p_menu_misji = new Menu_misji();
   
  Menu_pomocy* p_menu_pomocy = NULL;
  p_menu_pomocy = new Menu_pomocy();


 install_keyboard();
 set_keyboard_rate(10, 5);
 install_mouse();
 text_mode(-1);

/////////////WYODREBNIC STEROWANIE DLA DRUGIEJ ROZDZIELCZOSCI !!!!!!!!!!

 while(! key[KEY_ESC]) {
 //DOSTEPNE WSZEDZIE
        if (key[KEY_F10]) {
              p_tryb_grafiki->zmien_tryb_okno();
        }

//EDYCJA MAPY - Z MAPKA
 if (akcja1 == 0) {
/*        if (key[KEY_F9]) {
              p_tryb_grafiki->zmien_tryb_nastepny();
              rozdzielczosc = p_tryb_grafiki->ustawiony_tryb();       
        }*/
        if (key[KEY_ALT]) {
              p_interfejs->schowaj();
        }
        if (key[KEY_LCONTROL]) {
              p_interfejs->pokaz();
        }
        if (key[KEY_A] || ((mouse_b & 1)&&(mouse_x>698)&&(mouse_x<714)&&(mouse_y>23)&&(mouse_y<37)) ) {
              p_interfejs->zmien_kategorie_lewo();
        }
        if (key[KEY_S] || ((mouse_b & 1)&&(mouse_x>772)&&(mouse_x<786)&&(mouse_y>23)&&(mouse_y<37))) {
              p_interfejs->zmien_kategorie_prawo();
        }
        if (key[KEY_TAB]) {
              p_obszar_edycji->ustaw_siatke();
        }
        if (key[KEY_CAPSLOCK]) {
              p_obszar_edycji->ustaw_skale();
        }
        if (key[KEY_SPACE]) {
              p_obszar_edycji->wlacz_mape();
        }
        if (key[KEY_TILDE]) {
              p_obszar_edycji->zmien_skale_mapy();
        }
        if (key[KEY_CAPSLOCK]) {
              p_obszar_edycji->ustaw_skale();
        }
        if (key[KEY_LEFT] || mouse_x < 10) {
              p_obszar_edycji->przesun_lewo();
        }
        if (key[KEY_RIGHT] || mouse_x > SCREEN_W-1-10) {
              p_obszar_edycji->przesun_prawo();
        }
        if (key[KEY_UP] || mouse_y < 10) {
              p_obszar_edycji->przesun_gora();
        }
        if (key[KEY_DOWN] || mouse_y > SCREEN_H-1-10) {
              p_obszar_edycji->przesun_dol();
        }
        
        if (key[KEY_F1]) {
              akcja1 = 2;
              akcja2 = 0;
        }
        if (key[KEY_F2]) {
              p_obszar_edycji->quick_save();
        }
        if (key[KEY_F3]) {
              p_obszar_edycji->quick_load();
        }

        if (key[KEY_F6]) {//load
              akcja1 = 1;
              akcja2 = 0;
        }
}



/////////////////////////////////////////EVENTY Z MYSZY//////////////////////////////////////////////////////

if (akcja1 == 0) {
         //prawa strona ekranu - wybor kategorii z obiektami
   if ((mouse_b & 1)&&(mouse_x>712)&&(mouse_x<768)&&(mouse_y>24)&&(mouse_y<31)) {
      if (mouse_x<720) {p_interfejs-> wybierz_kategorie(0);}
      else if (mouse_x<728) {p_interfejs-> wybierz_kategorie(1);}
      else if (mouse_x<736) {p_interfejs-> wybierz_kategorie(2);}
      else if (mouse_x<744) {p_interfejs-> wybierz_kategorie(3);}
      else if (mouse_x<752) {p_interfejs-> wybierz_kategorie(4);}
      else if (mouse_x<760) {p_interfejs-> wybierz_kategorie(5);}
      else if (mouse_x<768) {p_interfejs-> wybierz_kategorie(6);}
   }


         //wybieranie obiektow do wstawienia
   if ((mouse_b & 1)&&(mouse_x>701)&&(mouse_x<781)&&(mouse_y>52)&&(mouse_y<403)) {
      //lewy pas
      if (mouse_x<701+36) {
         if (mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 32) {p_interfejs->wybierz_obiekt(0);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 40 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 72) {p_interfejs->wybierz_obiekt(2);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 80 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 112) {p_interfejs->wybierz_obiekt(4);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 120 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 152) {p_interfejs->wybierz_obiekt(6);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 160 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 192) {p_interfejs->wybierz_obiekt(8);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 200 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 232) {p_interfejs->wybierz_obiekt(10);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 240 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 272) {p_interfejs->wybierz_obiekt(12);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 280 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 312) {p_interfejs->wybierz_obiekt(14);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 320 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 352) {p_interfejs->wybierz_obiekt(16);}
      }
      //prawy pas
      else if (mouse_x>701+44) {
         if (mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 32) {p_interfejs->wybierz_obiekt(1);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 40 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 72) {p_interfejs->wybierz_obiekt(3);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 80 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 112) {p_interfejs->wybierz_obiekt(5);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 120 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 152) {p_interfejs->wybierz_obiekt(7);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 160 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 192) {p_interfejs->wybierz_obiekt(9);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 200 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 232) {p_interfejs->wybierz_obiekt(11);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 240 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 272) {p_interfejs->wybierz_obiekt(13);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 280 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 312) {p_interfejs->wybierz_obiekt(15);}
         else if (mouse_y>PRZYCISKI_OBIEKTOW_OD_GORY + 320 && mouse_y<PRZYCISKI_OBIEKTOW_OD_GORY + 352) {p_interfejs->wybierz_obiekt(17);}
      }
   }
      //klikniecie na przycisk "ustawienia mapy"
   if ((mouse_b & 1)&&(mouse_x>690)&&(mouse_x<790)&&(mouse_y>540)&&(mouse_y<572)) {
      akcja1 = 3;
         
   }
}

//////////////////////////////////////////////////WYSWIETLANIE GRAFIKI////////////////////////////////////////////////////
 if (akcja1 == 0) {
   //wyswietlanie podkladu, obszaru edycji oraz mapy w lewym gornym rogu
   clear_to_color(buffer, 0x7B7352);
   p_obszar_edycji->wyswietl_mapke(buffer);
   p_obszar_edycji->wyswietl_mape(buffer);
  
   if ((mouse_x>20)&&(mouse_x<680)&&(mouse_y>20)&&(mouse_y<580)) {
       p_obszar_edycji->wyswietl_maly_prostokat(buffer, (p_obszar_edycji->wskaz_pole(mouse_x, mouse_y)));
   }

   
   p_interfejs->wyswietl_interfejs(buffer);
   p_interfejs->wyswietl_wybrany_obiekt(buffer);

   //kursor w obszarze edycji - wstawiamy obiekt
   if ((mouse_x>20)&&(mouse_x<680)&&(mouse_y>20)&&(mouse_y<580)) {
      //przenioslem
      //p_obszar_edycji->wyswietl_maly_prostokat(buffer, (p_obszar_edycji->wskaz_pole(mouse_x, mouse_y)));
        if (mouse_b & 1) //wstawiamy element
           p_obszar_edycji->wpisz_do_matrycy(p_interfejs->literka_wybranego_obiektu(), (p_obszar_edycji->wskaz_pole(mouse_x, mouse_y)) % (p_obszar_edycji->szer_mapy()), (p_obszar_edycji->wskaz_pole(mouse_x, mouse_y)) / p_obszar_edycji->szer_mapy());
        else if (mouse_b & 2)
           p_obszar_edycji->wpisz_do_matrycy(' ', (p_obszar_edycji->wskaz_pole(mouse_x, mouse_y)) % (p_obszar_edycji->szer_mapy()), (p_obszar_edycji->wskaz_pole(mouse_x, mouse_y)) / p_obszar_edycji->szer_mapy());                  
   }          

   switch (p_tryb_grafiki->zwroc_ekran_width()) {
     case 800 :
//       textout_centre_ex(BITMAP *bmp, const FONT *f, const char *s, int x, y, color, bg);
       rectfill(buffer, SCREEN_W/2 - 150, SCREEN_H-16, SCREEN_W/2 + 150, SCREEN_H - 5, 55000);
       textout_centre(buffer, font, " w w w . p o l a n i e . p r v . p l", SCREEN_W/2, SCREEN_H-14, 10);
       //wskaznik pozycji kursora
       rectfill(buffer, 40, SCREEN_H-16, 110, SCREEN_H - 5, 55000);
       textout_centre(buffer, font, intToChar(mouse_x), 60, SCREEN_H-13, 10);
       textout_centre(buffer, font, intToChar(mouse_y), 60+30, SCREEN_H-13, 10);
       //wskaznik nr pola, nad ktorym jest kursor
       rectfill(buffer, 120, SCREEN_H-16, 170, SCREEN_H - 5, 55000);
       textout_centre(buffer, font, intToChar(p_obszar_edycji->wskaz_pole(mouse_x, mouse_y)), 145, SCREEN_H-13, 10);
       break;
     case 1024 :
       textout_centre(buffer, font, "www.polanie.prv.pl", SCREEN_W/2, 1, 10);
       break;
   }


 }//if (akcja1 == 0)

   
 else if (akcja1 == 1) {
        if (key[KEY_SPACE]) {       //powrot do edycji
              akcja1 = 0;
//              p_obszar_edycji->load(17);
        }
        if (key[KEY_LEFT]) {
              p_menu_misji->zmien_misje(-1);
        }
        if (key[KEY_RIGHT]) {
              p_menu_misji->zmien_misje(1);
        }
        if (key[KEY_UP]) {
              p_menu_misji->zmien_misje(-5);
        }
        if (key[KEY_DOWN]) {
              p_menu_misji->zmien_misje(5);
        }
        if (key[KEY_ENTER]) {
              if (p_menu_misji->wybrana_misja() > 0 && p_menu_misji->wybrana_misja() <= 25) {              
                 p_obszar_edycji->load(p_menu_misji->wybrana_misja());
                 akcja1 = 0;
              }
        }
        p_menu_misji->Rysuj_menu_misji(buffer);
         
 }
 else if (akcja1 == 2) {
        if (key[KEY_SPACE]) {       //powrot do edycji
              akcja1 = 0;
        }
        p_menu_pomocy->Rysuj_menu_pomocy(buffer);
 }
 
 else if (akcja1 == 3) {                         //ustawienia mapki
        if (key[KEY_SPACE]) {       //powrot do edycji
              akcja1 = 0;
        }
        if ((mouse_b & 1)&&(mouse_x>240)&&(mouse_x<259)) {    //kursor w pasie pionowym 
              if((mouse_y>140)&&(mouse_y<156)) { p_obszar_edycji->zmien_mleko(); }
              else if ((mouse_y>170)&&(mouse_y<186)) { p_obszar_edycji->zmien_czy_generowana_postac(); }
              else if ((mouse_y>200)&&(mouse_y<216)) { p_obszar_edycji->zmien_typ_rozgrywki(); }
              else if ((mouse_y>230)&&(mouse_y<246)) { p_obszar_edycji->zmien_rodzaj_zakonczenia(); }
              else if ((mouse_y>260)&&(mouse_y<276)&&(p_obszar_edycji->zwroc_rodzaj_zakonczenia() == 1)) { p_obszar_edycji->zmien_postac_kluczowa(); }
              else if ((mouse_y>260)&&(mouse_y<276)&&(p_obszar_edycji->zwroc_rodzaj_zakonczenia() == 2)) { p_obszar_edycji->zmien_liczba_chat(); }
        }

                                                                      
        p_obszar_edycji->wyswietl_ustawienia_mapy(buffer);
 }


   


   

 show_mouse(buffer);
 vsync();
 blit(buffer,screen,0,0,0,0,p_tryb_grafiki->zwroc_ekran_width(),p_tryb_grafiki->zwroc_ekran_height());
 clear_keybuf();
 }//while - main loop 
 // Exit program.
 allegro_exit();
 return 0;     
}     

// Some Allegro magic to deal with WinMain().
END_OF_MAIN();
