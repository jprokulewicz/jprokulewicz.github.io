#define MAPA_OD_GORY 20
#define MAPA_OD_LEWEJ 20

#include <allegro.h>
#include "obszar_edycji.h"
extern int rozdzielczosc;
extern int wys;
extern int szer;


