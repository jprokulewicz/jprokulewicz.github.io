#include <allegro.h>
extern int rozdzielczosc;




