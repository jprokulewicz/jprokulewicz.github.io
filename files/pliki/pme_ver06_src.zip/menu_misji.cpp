#include "menu_misji.h"
#include "konwersja.h"

#define POZ_X 245
#define POZ_Y 150
#define ODSTEP_X 70
#define ODSTEP_Y 70



Menu_misji::Menu_misji(void) {
      aktywna_misja = 13;
      liczba_misji = 25;

      PALETTE palette;
      pusty_przycisk = load_bitmap("grafika/interfejs_pusty_przycisk.pcx", palette);
}

void Menu_misji::wybierz_misje(int wybrana_wartosc) {
      aktywna_misja = wybrana_wartosc;
}

void Menu_misji::Rysuj_menu_misji(BITMAP * ekran) {
      rectfill(ekran, 200, 100, 600, 500, 0);
      masked_stretch_blit(pusty_przycisk,ekran,0,0,18,16, 200, 100, 400, 400);
      rectfill(ekran, 325, 105, 473, 121, 0);
      textout_centre(ekran, font, "WCZYTYWANIE MAPY", SCREEN_W/2, 110, 65000);
      //podswietlenie wybranej misji
      rectfill(ekran, POZ_X + (aktywna_misja%5)*ODSTEP_X, POZ_Y + (aktywna_misja/5)*ODSTEP_Y, POZ_X + (aktywna_misja%5)*ODSTEP_X + 34, POZ_Y + (aktywna_misja/5)*ODSTEP_Y + 30, 65336);
      for (int i = 0; i < liczba_misji; i++ ) {
         masked_stretch_blit(pusty_przycisk,ekran,0,0,18,16, POZ_X + (i%5)*ODSTEP_X, POZ_Y + (i/5)*ODSTEP_Y, 36, 32);
         textout_centre(ekran, font, intToChar(i+1), POZ_X + (i%5)*ODSTEP_X + 18, POZ_Y + (i/5)*ODSTEP_Y + 13, 65000); 
      }
}

void Menu_misji::zmien_misje(int o_ile) {
     aktywna_misja += o_ile;
     if (aktywna_misja < 0) aktywna_misja = 0;
     aktywna_misja %= liczba_misji;
}

int Menu_misji::wybrana_misja(void) {
    return aktywna_misja+1;
}
