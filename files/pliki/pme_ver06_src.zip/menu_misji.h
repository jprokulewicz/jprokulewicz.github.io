#include <allegro.h>

class Menu_misji {
      int aktywna_misja;
      int liczba_misji;
      BITMAP* pusty_przycisk;
      
public:
      Menu_misji(void);
      void wybierz_misje(int wybrana_wartosc);
      void zmien_misje(int o_ile);
      int wybrana_misja(void);
      void Rysuj_menu_misji(BITMAP * ekran);
};
