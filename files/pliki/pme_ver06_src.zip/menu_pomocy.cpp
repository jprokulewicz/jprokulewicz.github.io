#include "menu_pomocy.h"

#define POZ_X 245
#define POZ_Y 150
#define ODSTEP_X 70
#define ODSTEP_Y 70



Menu_pomocy::Menu_pomocy(void) {
      aktywna_plansza = 0;
      liczba_plansz = 2;

      PALETTE palette;
      pusty_przycisk = load_bitmap("grafika/interfejs_pusty_przycisk.pcx", palette);
}

void Menu_pomocy::Rysuj_menu_pomocy(BITMAP * ekran) {
      rectfill(ekran, 200, 100, 600, 500, 0);
      masked_stretch_blit(pusty_przycisk,ekran,0,0,18,16, 200, 100, 400, 400);
      rectfill(ekran, 325, 105, 473, 121, 0);
      textout_centre(ekran, font, "POMOC", SCREEN_W/2, 110, 65000);

      //tekst
      textout(ekran, font, "Klawiszologia:", 240, 140, 65000);
      textout(ekran, font, "F1 - pomoc", 240, 160, 65000);
      textout(ekran, font, "F2 - szybki zapis mapy", 240, 175, 65000);
      textout(ekran, font, "F3 - szybki odczyt mapy", 240, 190, 65000);
      textout(ekran, font, "F5 - zapis mapy", 240, 205, 65000);
      textout(ekran, font, "F6 - odczyt mapy", 240, 220, 65000);
      textout(ekran, font, "F10 - tryb pelnoekranowy", 240, 235, 65000);
      textout(ekran, font, "~ - skalowanie mapki", 240, 250, 65000);
      textout(ekran, font, "spacja - pokaz/schowaj mapke", 240, 265, 65000);
      textout(ekran, font, "tab - wlacz/wylacz siatke", 240, 280, 65000);
      textout(ekran, font, "caps lock - zoom obszaru edycji", 240, 295, 65000);
      //void textout_ex(BITMAP *bmp, const FONT *f, const char *s, int x, y, color, bg);
      
      textout_centre(ekran, font, "spacja --- powrot do edycji mapy", SCREEN_W/2, 455, 65000);
}

void Menu_pomocy::wybierz_plansze(int na_jaka) {
     aktywna_plansza = na_jaka;
}

int Menu_pomocy::wybrana_plansza(void) {
    return aktywna_plansza;
}

