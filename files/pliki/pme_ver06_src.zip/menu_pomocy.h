#include <allegro.h>

class Menu_pomocy {
      int aktywna_plansza;
      int liczba_plansz;
      BITMAP* pusty_przycisk;
      
public:
      Menu_pomocy(void);
      void wybierz_plansze(int na_jaka);
      int wybrana_plansza(void);
      void Rysuj_menu_pomocy(BITMAP * ekran);
};
