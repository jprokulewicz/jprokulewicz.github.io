//#define SZEROKOSC_MAPY 16
//#define WYSOKOSC_MAPY 16
#define LICZBA_POL_X 10
#define LICZBA_POL_Y 10
#define OBSZAR_GRY_TOP 20
#define OBSZAR_GRY_LEFT 20
#define MAPA_OD_GORY 20
#define MAPA_OD_LEWEJ 20

#include "obszar_edycji.h"
#include <allegro.h>
#include "konwersja.h"

extern int rozdzielczosc;


Obszar_edycji::Obszar_edycji(int wysokosc, int szerokosc){
  this->poz_x = 0;
  this->poz_y = 0;
  this->szer = szerokosc;
  this->wys = wysokosc;
  this->czy_siatka = 1;
  this->skala = 1;
  this->obszar_gry_left = OBSZAR_GRY_LEFT;
  this->obszar_gry_top = OBSZAR_GRY_TOP;
  matryca = new char*[wysokosc];
  for (int i=0; i<(wysokosc); i++) {
     matryca[i] = new char[szerokosc];
  };

  PALETTE palette;  
//  drzewo = load_bitmap("obiekty/2A_drzewo.pcx", palette);
//  trawa = load_bitmap("obiekty/0_spacja_trawa.pcx", palette);
//  square = load_bitmap("obiekty/inne/square.pcx", palette);  


   
     obiekty_0[0] = load_bitmap("obiekty/0_spacja_trawa.pcx", palette);
     obiekty_0[1] = load_bitmap("obiekty/0q_sucha_ziemia.pcx", palette);     
     obiekty_0[2] = load_bitmap("obiekty/0_I_z_kreska_skaly.pcx", palette);
     obiekty_0[3] = load_bitmap("obiekty/0_A_z_dwiema_kropkami_skaly.pcx", palette);
     obiekty_0[4] = load_bitmap("obiekty/0_ll_skaly.pcx", palette);
     obiekty_0[5] = load_bitmap("obiekty/0_s_z_fajka_skaly.pcx", palette);
     obiekty_0[6] = load_bitmap("obiekty/0_U_z_kreska_skaly.pcx", palette);
     obiekty_0[7] = load_bitmap("obiekty/0_srodkowa_kropka_skaly.pcx", palette);
     obiekty_0[8] = load_bitmap("obiekty/0_O_z_daszkiem_skaly.pcx", palette);
     obiekty_0[9] = load_bitmap("obiekty/0_L_z_kreska_skaly.pcx", palette);
     obiekty_0[10] = load_bitmap("obiekty/0_E_z_kreska_skaly.pcx", palette);           
     obiekty_0[11] = load_bitmap("obiekty/0_przecinek_skaly.pcx", palette);
     obiekty_0[12] = load_bitmap("obiekty/0_O_z_kreska_skaly.pcx", palette);
     obiekty_0[13] = load_bitmap("obiekty/0_U_z_kwadracikiem_skaly.pcx", palette);
     obiekty_0[14] = load_bitmap("obiekty/0s_przejscie_miedzy_skalami.pcx", palette);
     obiekty_0[15] = load_bitmap("obiekty/1t_droga.pcx", palette);

     obiekty_1[0] = load_bitmap("obiekty/12_most.pcx", palette);
     obiekty_1[1] = load_bitmap("obiekty/15_most.pcx", palette);
     obiekty_1[2] = load_bitmap("obiekty/11_most.pcx", palette);
     obiekty_1[3] = load_bitmap("obiekty/13_most.pcx", palette);
     obiekty_1[4] = load_bitmap("obiekty/14_most.pcx", palette);
     obiekty_1[5] = load_bitmap("obiekty/16_most.pcx", palette);
     obiekty_1[6] = load_bitmap("obiekty/17_most.pcx", palette);
     obiekty_1[7] = load_bitmap("obiekty/18_most.pcx", palette);
     obiekty_1[8] = load_bitmap("obiekty/1w_woda.pcx", palette);

     obiekty_2[0] = load_bitmap("obiekty/2A_drzewo.pcx", palette);          
     obiekty_2[1] = load_bitmap("obiekty/2B_drzewo.pcx", palette);
     obiekty_2[2] = load_bitmap("obiekty/2C_drzewo.pcx", palette);
     obiekty_2[3] = load_bitmap("obiekty/2D_drzewo.pcx", palette);
     obiekty_2[4] = load_bitmap("obiekty/2E_drzewo.pcx", palette);        
     obiekty_2[5] = load_bitmap("obiekty/2F_drzewo.pcx", palette);
     obiekty_2[6] = load_bitmap("obiekty/2G_drzewo_suche.pcx", palette);
     obiekty_2[7] = load_bitmap("obiekty/2a_pien.pcx", palette);
     obiekty_2[8] = load_bitmap("obiekty/2b_kamienie.pcx", palette);
     obiekty_2[9] = load_bitmap("obiekty/2c_kamienie.pcx", palette);         
     obiekty_2[10] = load_bitmap("obiekty/2j_kamien_wysoki.pcx", palette);
     obiekty_2[11] = load_bitmap("obiekty/2d_kamienie.pcx", palette);
     obiekty_2[12] = load_bitmap("obiekty/2m_kamien_duzy.pcx", palette);
     obiekty_2[13] = load_bitmap("obiekty/2n_kamienie.pcx", palette);

     obiekty_3[0] = load_bitmap("obiekty/3H_budynek_glowny.pcx", palette);     
     obiekty_3[1] = load_bitmap("obiekty/3I_obora.pcx", palette);        
     obiekty_3[2] = load_bitmap("obiekty/3J_chata_mieszkalna.pcx", palette);
     obiekty_3[3] = load_bitmap("obiekty/3L_chata_wojow.pcx", palette);
     obiekty_3[4] = load_bitmap("obiekty/3K_dwor_mocy.pcx", palette);
     obiekty_3[5] = load_bitmap("obiekty/3M_dwor_rycerza.pcx", palette);
     obiekty_3[6] = load_bitmap("obiekty/3r_palisada.pcx", palette);
     obiekty_3[7] = load_bitmap("obiekty/3x_krowa.pcx", palette);     
     obiekty_3[8] = load_bitmap("obiekty/3y_drwal.pcx", palette);
     obiekty_3[9] = load_bitmap("obiekty/3z_mysliwy.pcx", palette);
     obiekty_3[10] = load_bitmap("obiekty/3_dwukropek_miecznik.pcx", palette);          
     obiekty_3[11] = load_bitmap("obiekty/3_srednik_wlocznik.pcx", palette);   
     obiekty_3[12] = load_bitmap("obiekty/39_kaplanka.pcx", palette);
     obiekty_3[13] = load_bitmap("obiekty/30_kaplan.pcx", palette);         
     obiekty_3[14] = load_bitmap("obiekty/3_znak_mniejszosci_rycerz.pcx", palette);     
     obiekty_3[15] = load_bitmap("obiekty/3_znak_wiekszosci_niedzwiedz.pcx", palette);             
     obiekty_3[16] = load_bitmap("obiekty/3_przecinek_strzyga.pcx", palette);          

     obiekty_4[0] = load_bitmap("obiekty/4N_wrogi_budynek_glowny.pcx", palette);
     obiekty_4[1] = load_bitmap("obiekty/4O_wroga_obora.pcx", palette);
     obiekty_4[2] = load_bitmap("obiekty/4P_wroga_chata_mieszkalna.pcx", palette);
     obiekty_4[3] = load_bitmap("obiekty/4R_wroga_chata_wojow.pcx", palette);
     obiekty_4[4] = load_bitmap("obiekty/4Q_wrogi_dwor_mocy.pcx", palette);
     obiekty_4[5] = load_bitmap("obiekty/4S_wrogi_dwor_rycerza.pcx", palette);
     obiekty_4[6] = load_bitmap("obiekty/4T_wroga_krowa.pcx", palette);
     obiekty_4[7] = load_bitmap("obiekty/4U_wrogi_drwal.pcx", palette);
     obiekty_4[8] = load_bitmap("obiekty/4W_wrogi_mysliwy.pcx", palette);
     obiekty_4[9] = load_bitmap("obiekty/4Z_wrogi_miecznik.pcx", palette);
     obiekty_4[10] = load_bitmap("obiekty/4_hasz_wrogi_wlocznik.pcx", palette);
     obiekty_4[11] = load_bitmap("obiekty/4X_wroga_kaplanka.pcx", palette);
     obiekty_4[12] = load_bitmap("obiekty/4Y_wrogi_kaplan.pcx", palette);
     obiekty_4[13] = load_bitmap("obiekty/4_podwojny_cudzyslow_wrogi_rycerz.pcx", palette);
     obiekty_4[14] = load_bitmap("obiekty/4_procent_wrogi_niedzwiedz.pcx", palette);
     obiekty_4[15] = load_bitmap("obiekty/4_ampersand_wroga_strzyga.pcx", palette);

     obiekty_5[0] = load_bitmap("obiekty/5e_tabliczka.pcx", palette);          
     obiekty_5[1] = load_bitmap("obiekty/5f_sciezka.pcx", palette);          
     obiekty_5[2] = load_bitmap("obiekty/5g_sadzawka.pcx", palette);   
     obiekty_5[3] = load_bitmap("obiekty/5h_pal.pcx", palette);
     obiekty_5[4] = load_bitmap("obiekty/5i_slupek_z_czaszka.pcx", palette);             
     obiekty_5[5] = load_bitmap("obiekty/5k_studnia.pcx", palette);         
     obiekty_5[6] = load_bitmap("obiekty/5l_kamienny_stolik_ofiarny.pcx", palette);
     obiekty_5[7] = load_bitmap("obiekty/5o_ognisko_male.pcx", palette);     
     obiekty_5[8] = load_bitmap("obiekty/5p_ognisko_duze.pcx", palette);        
     
     obiekty_6[0] = load_bitmap("obiekty/6_ukosnik_miejsce_przemiany.pcx", palette);
     obiekty_6[1] = load_bitmap("obiekty/6_kropka_uzdrowisko.pcx", palette);
     obiekty_6[2] = load_bitmap("obiekty/6_daszek_miejsce_docelowe.pcx", palette);
     obiekty_6[3] = load_bitmap("obiekty/6_gwiazdka_jednostka_specjalna.pcx", palette);          
     obiekty_6[4] = load_bitmap("obiekty/6_minus_pastwisko_wroga.pcx", palette);
     obiekty_6[5] = load_bitmap("obiekty/6_plus_odkryty_teren.pcx", palette);             
     obiekty_6[6] = load_bitmap("obiekty/6_pytajnik_miejsce_zbiorki.pcx", palette);         
     obiekty_6[7] = load_bitmap("obiekty/6_rownosc_miejsce_rozpoczecia_misji.pcx", palette);
     
     pusty_przycisk = load_bitmap("grafika/interfejs_pusty_przycisk.pcx", palette);


  prostokat_maly = load_bitmap("grafika/kursory/prostokat_maly.pcx", palette);     
  drzewo = load_bitmap("obiekty/drzewo.pcx", palette);  
  trawa = load_bitmap("obiekty/trawa.pcx", palette);
  square = load_bitmap("obiekty/square.pcx", palette);

  
  wyczysc_mapke();
//DO MAPY
     this->czy_wlaczona_mapa = 1;
     this->skala_mapy = 2;
     mapa = create_bitmap(64, 64);

     obwodka[0] = 42;
     obwodka[1] = 40;
     obwodka[2] = 21;
     obwodka[3] = 20;
     obwodka[4] = 14;
     obwodka[5] = 14;
     kolor_nieb = makecol16(0, 47, 143);
     kolor_czer = makecol16(192, 0, 0);
     kolor_braz_jasny = makecol16(80, 48, 15);
     kolor_braz_sredni = makecol16(64, 32, 0);
     kolor_braz_ciemny = makecol16(48, 16, 0);
     kolor_ziel_jasny = makecol16(0, 80, 0);
     kolor_ziel_ciemny = makecol16(0, 48, 0);
     kolor_poma = makecol16(239, 160, 0);
     kolor_poma_ciemny = makecol16(255, 109, 1);
     kolor_bial = makecol16(255, 255, 255);
     kolor_szar = makecol16(79, 79, 79);
     kolor_czar = makecol16(0, 0, 0);
     
     
//ZAPISYWANIE DO PLIKU

//USTAWIENIA MAPY
      mleko = 0;
      czy_generowana_postac = 0;
      typ_rozgrywki = 0;
      rodzaj_zakonczenia = 0;
      postac_kluczowa = 0;
      liczba_chat = 0;
      
}

void Obszar_edycji::wyczysc_mapke(void){
  for (int i=0; i<(wys); i++) {
    for (int j=0; j<(szer); j++)
     matryca[i][j] = ' ';
  }
  matryca[0][0] = 'A';  
  matryca[1][1] = 'A';
  matryca[1][2] = 'A';
  matryca[2][1] = 'A';
  matryca[2][2] = 'A';
  matryca[7][7] = '�';
  matryca[7][8] = 'A';
  matryca[8][7] = 'A';  
  matryca[8][8] = 'd';
  
  matryca[6][5] = 'B';
    
  matryca[5][8] = '�';
  matryca[6][6] = '�';
  matryca[6][7] = '�';  
  matryca[6][8] = '�';
  matryca[7][6] = 'A';  
  matryca[7][7] = 'A';
  matryca[7][8] = 'A';
  matryca[8][6] = 'q';  
  matryca[5][9] = '�';
  matryca[8][8] = 'A';  
  matryca[9][9] = 'A';

  matryca[20][22] = '�';  
  matryca[21][21] = '�';
  matryca[21][22] = '�';
  matryca[21][23] = '�';
  matryca[25][25] = '�';
  matryca[27][27] = '�';
  matryca[27][27] = '�';  
  matryca[27][28] = 's';
  matryca[28][27] = 't';  
  matryca[28][28] = 'A';

  matryca[10][59] = 'q';
  matryca[11][59] = 'q';  
  matryca[11][60] = 'q';  
  
  matryca[10][63] = 'q';
  matryca[11][63] = 'q';  
  matryca[10][62] = 'q';
  matryca[10][55] = 'q';
  matryca[53][11] = 'q';  
  matryca[60][10] = 'q';  
  matryca[63][10] = 'q';
  matryca[63][11] = 'q';
  matryca[63][63] = 'q';  
}

void Obszar_edycji::wyswietl_mapke(BITMAP* ekran){
  for (int i=poz_y; i<wys; i++) {  //rysowanie trawy na calej mapie
    for (int j=poz_x; j<szer; j++) {
      stretch_blit(trawa,ekran,0,0,trawa->w,trawa->h,obszar_gry_left+(j-poz_x)*skala*16, obszar_gry_top+(i-poz_y)*skala*14, skala*(trawa->w), skala*(trawa->h));
    }
  }
  for (int i=poz_y; i<wys; i++) {     //rysowanie siatki na mapie
    for (int j=poz_x; j<szer; j++) {
      if (czy_siatka)
        masked_stretch_blit(square,ekran,0,0,square->w,square->h,obszar_gry_left+(j-poz_x)*skala*16, obszar_gry_top+(i-poz_y)*skala*14, skala*(square->w), skala*(square->h));                                  
    }
  }
     
  for (int i=poz_y; i<wys; i++) {
    for (int j=poz_x; j<szer; j++) {
     switch (matryca[i][j]) {
            case 'q':
                 masked_stretch_blit(obiekty_0[1],ekran,0,0,obiekty_0[1]->w,obiekty_0[1]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[1]->w,skala*obiekty_0[1]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[2],ekran,0,0,obiekty_0[2]->w,obiekty_0[2]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[2]->w,skala*obiekty_0[2]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[3],ekran,0,0,obiekty_0[3]->w,obiekty_0[3]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[3]->w,skala*obiekty_0[3]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[4],ekran,0,0,obiekty_0[4]->w,obiekty_0[4]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[4]->w,skala*obiekty_0[4]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[5],ekran,0,0,obiekty_0[5]->w,obiekty_0[5]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[5]->w,skala*obiekty_0[5]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[6],ekran,0,0,obiekty_0[6]->w,obiekty_0[6]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[6]->w,skala*obiekty_0[6]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[7],ekran,0,0,obiekty_0[7]->w,obiekty_0[7]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[7]->w,skala*obiekty_0[7]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[8],ekran,0,0,obiekty_0[8]->w,obiekty_0[8]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[8]->w,skala*obiekty_0[8]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[9],ekran,0,0,obiekty_0[9]->w,obiekty_0[9]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[9]->w,skala*obiekty_0[9]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[10],ekran,0,0,obiekty_0[10]->w,obiekty_0[10]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[10]->w,skala*obiekty_0[10]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[11],ekran,0,0,obiekty_0[11]->w,obiekty_0[11]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[11]->w,skala*obiekty_0[11]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[12],ekran,0,0,obiekty_0[12]->w,obiekty_0[12]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[12]->w,skala*obiekty_0[12]->h);
                 break;
            case '�':
                 masked_stretch_blit(obiekty_0[13],ekran,0,0,obiekty_0[13]->w,obiekty_0[13]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[13]->w,skala*obiekty_0[13]->h);
                 break;
            case 's':
                 masked_stretch_blit(obiekty_0[14],ekran,0,0,obiekty_0[14]->w,obiekty_0[14]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[14]->w,skala*obiekty_0[14]->h);
                 break;
            case 't':
                 masked_stretch_blit(obiekty_0[15],ekran,0,0,obiekty_0[15]->w,obiekty_0[15]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_0[15]->w,skala*obiekty_0[15]->h);
                 break;
                 //DRUGA ZAKLADKA
            case '2':
                 masked_stretch_blit(obiekty_1[0],ekran,0,0,obiekty_1[0]->w,obiekty_1[0]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_1[0]->w,skala*obiekty_1[0]->h);
                 break;
            case '5':
                 masked_stretch_blit(obiekty_1[1],ekran,0,0,obiekty_1[1]->w,obiekty_1[1]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_1[1]->w,skala*obiekty_1[1]->h);
                 break;
            case '1':
                 masked_stretch_blit(obiekty_1[2],ekran,0,0,obiekty_1[2]->w,obiekty_1[2]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_1[2]->w,skala*obiekty_1[2]->h);
                 break;
            case '3':
                 masked_stretch_blit(obiekty_1[3],ekran,0,0,obiekty_1[3]->w,obiekty_1[3]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_1[3]->w,skala*obiekty_1[3]->h);
                 break;
            case '4':
                 masked_stretch_blit(obiekty_1[4],ekran,0,0,obiekty_1[4]->w,obiekty_1[4]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_1[4]->w,skala*obiekty_1[4]->h);
                 break;
            case '6':
                 masked_stretch_blit(obiekty_1[5],ekran,0,0,obiekty_1[5]->w,obiekty_1[5]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_1[5]->w,skala*obiekty_1[5]->h);
                 break;
            case '7':
                 masked_stretch_blit(obiekty_1[6],ekran,0,0,obiekty_1[6]->w,obiekty_1[6]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_1[6]->w,skala*obiekty_1[6]->h);
                 break;
            case '8':
                 masked_stretch_blit(obiekty_1[7],ekran,0,0,obiekty_1[7]->w,obiekty_1[7]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_1[7]->w,skala*obiekty_1[7]->h);
                 break;
            case 'w':
                 masked_stretch_blit(obiekty_1[8],ekran,0,0,obiekty_1[8]->w,obiekty_1[8]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_1[8]->w,skala*obiekty_1[8]->h);
                 break;
                 //TRZECIA ZAKLADKA
            case 'A':
                 masked_stretch_blit(obiekty_2[0],ekran,0,0,obiekty_2[0]->w,obiekty_2[0]->h,obszar_gry_left+(j-poz_x)*skala*16-skala*7,obszar_gry_top+(i-poz_y)*skala*14-skala*15,skala*obiekty_2[0]->w,skala*obiekty_2[0]->h);
                 break;
            case 'B':
                 masked_stretch_blit(obiekty_2[1],ekran,0,0,obiekty_2[1]->w,obiekty_2[1]->h,obszar_gry_left+(j-poz_x)*skala*16-skala*7,obszar_gry_top+(i-poz_y)*skala*14-skala*15,skala*obiekty_2[1]->w,skala*obiekty_2[1]->h);
                 break;
            case 'C':
                 masked_stretch_blit(obiekty_2[2],ekran,0,0,obiekty_2[2]->w,obiekty_2[2]->h,obszar_gry_left+(j-poz_x)*skala*16-skala*7,obszar_gry_top+(i-poz_y)*skala*14-skala*15,skala*obiekty_2[2]->w,skala*obiekty_2[2]->h);
                 break;
            case 'D':
                 masked_stretch_blit(obiekty_2[3],ekran,0,0,obiekty_2[3]->w,obiekty_2[3]->h,obszar_gry_left+(j-poz_x)*skala*16-skala*7,obszar_gry_top+(i-poz_y)*skala*14-skala*15,skala*obiekty_2[3]->w,skala*obiekty_2[3]->h);
                 break;
            case 'E':
                 masked_stretch_blit(obiekty_2[4],ekran,0,0,obiekty_2[4]->w,obiekty_2[4]->h,obszar_gry_left+(j-poz_x)*skala*16-skala*7,obszar_gry_top+(i-poz_y)*skala*14-skala*15,skala*obiekty_2[4]->w,skala*obiekty_2[4]->h);
                 break;
            case 'F':
                 masked_stretch_blit(obiekty_2[5],ekran,0,0,obiekty_2[5]->w,obiekty_2[5]->h,obszar_gry_left+(j-poz_x)*skala*16-skala*7,obszar_gry_top+(i-poz_y)*skala*14-skala*15,skala*obiekty_2[5]->w,skala*obiekty_2[5]->h);
                 break;
            case 'G':
                 masked_stretch_blit(obiekty_2[6],ekran,0,0,obiekty_2[6]->w,obiekty_2[6]->h,obszar_gry_left+(j-poz_x)*skala*16-skala*7,obszar_gry_top+(i-poz_y)*skala*14-skala*15,skala*obiekty_2[6]->w,skala*obiekty_2[6]->h);
                 break;
            case 'a':
                 masked_stretch_blit(obiekty_2[7],ekran,0,0,obiekty_2[7]->w,obiekty_2[7]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_2[7]->w,skala*obiekty_2[7]->h);
                 break;
            case 'b':
                 masked_stretch_blit(obiekty_2[8],ekran,0,0,obiekty_2[8]->w,obiekty_2[8]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_2[8]->w,skala*obiekty_2[8]->h);
                 break;
            case 'c':
                 masked_stretch_blit(obiekty_2[9],ekran,0,0,obiekty_2[9]->w,obiekty_2[9]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_2[9]->w,skala*obiekty_2[9]->h);
                 break;
            case 'j':
                 masked_stretch_blit(obiekty_2[10],ekran,0,0,obiekty_2[10]->w,obiekty_2[10]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_2[10]->w,skala*obiekty_2[10]->h);
                 break;
            case 'd':
                 masked_stretch_blit(obiekty_2[11],ekran,0,0,obiekty_2[11]->w,obiekty_2[11]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_2[11]->w,skala*obiekty_2[11]->h);
                 break;
            case 'm':
                 masked_stretch_blit(obiekty_2[12],ekran,0,0,obiekty_2[12]->w,obiekty_2[12]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_2[12]->w,skala*obiekty_2[12]->h);
                 break;
            case 'n':
                 masked_stretch_blit(obiekty_2[13],ekran,0,0,obiekty_2[13]->w,obiekty_2[13]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_2[13]->w,skala*obiekty_2[13]->h);
                 break;
                 
                 //CZWARTA ZAKLADKA
            case 'H':
                 masked_stretch_blit(obiekty_3[0],ekran,0,0,obiekty_3[0]->w,obiekty_3[0]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_3[0]->w,skala*obiekty_3[0]->h);
                 break;
            case 'I':
                 masked_stretch_blit(obiekty_3[1],ekran,0,0,obiekty_3[1]->w,obiekty_3[1]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_3[1]->w,skala*obiekty_3[1]->h);
                 break;
            case 'J':
                 masked_stretch_blit(obiekty_3[2],ekran,0,0,obiekty_3[2]->w,obiekty_3[2]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_3[2]->w,skala*obiekty_3[2]->h);
                 break;
            case 'L':
                 masked_stretch_blit(obiekty_3[3],ekran,0,0,obiekty_3[3]->w,obiekty_3[3]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_3[3]->w,skala*obiekty_3[3]->h);
                 break;
            case 'K':
                 masked_stretch_blit(obiekty_3[4],ekran,0,0,obiekty_3[4]->w,obiekty_3[4]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_3[4]->w,skala*obiekty_3[4]->h);
                 break;
            case 'M':
                 masked_stretch_blit(obiekty_3[5],ekran,0,0,obiekty_3[5]->w,obiekty_3[5]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_3[5]->w,skala*obiekty_3[5]->h);
                 break;
            case 'r':
                 masked_stretch_blit(obiekty_3[6],ekran,0,0,obiekty_3[6]->w,obiekty_3[6]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[6]->w,skala*obiekty_3[6]->h);
                 break;
            case 'x':
                 masked_stretch_blit(obiekty_3[7],ekran,0,0,obiekty_3[7]->w,obiekty_3[7]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[7]->w,skala*obiekty_3[7]->h);
                 break;
            case 'y':
                 masked_stretch_blit(obiekty_3[8],ekran,0,0,obiekty_3[8]->w,obiekty_3[8]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[8]->w,skala*obiekty_3[8]->h);
                 break;
            case 'z':
                 masked_stretch_blit(obiekty_3[9],ekran,0,0,obiekty_3[9]->w,obiekty_3[9]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[9]->w,skala*obiekty_3[9]->h);
                 break;
            case ':':
                 masked_stretch_blit(obiekty_3[10],ekran,0,0,obiekty_3[10]->w,obiekty_3[10]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[10]->w,skala*obiekty_3[10]->h);
                 break;
            case ';':
                 masked_stretch_blit(obiekty_3[11],ekran,0,0,obiekty_3[11]->w,obiekty_3[11]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[11]->w,skala*obiekty_3[11]->h);
                 break;
            case '9':
                 masked_stretch_blit(obiekty_3[12],ekran,0,0,obiekty_3[12]->w,obiekty_3[12]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[12]->w,skala*obiekty_3[12]->h);
                 break;
            case '0':
                 masked_stretch_blit(obiekty_3[13],ekran,0,0,obiekty_3[13]->w,obiekty_3[13]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[13]->w,skala*obiekty_3[13]->h);
                 break;
            case '<':
                 masked_stretch_blit(obiekty_3[14],ekran,0,0,obiekty_3[14]->w,obiekty_3[14]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[14]->w,skala*obiekty_3[14]->h);
                 break;
            case '>':
                 masked_stretch_blit(obiekty_3[15],ekran,0,0,obiekty_3[15]->w,obiekty_3[15]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[15]->w,skala*obiekty_3[15]->h);
                 break;
            case ',':
                 masked_stretch_blit(obiekty_3[16],ekran,0,0,obiekty_3[16]->w,obiekty_3[16]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_3[16]->w,skala*obiekty_3[16]->h);
                 break;
                 
                 //PI�TA ZAKLADKA
            case 'N':
                 masked_stretch_blit(obiekty_4[0],ekran,0,0,obiekty_4[0]->w,obiekty_4[0]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_4[0]->w,skala*obiekty_4[0]->h);
                 break;
            case 'O':
                 masked_stretch_blit(obiekty_4[1],ekran,0,0,obiekty_4[1]->w,obiekty_4[1]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_4[1]->w,skala*obiekty_4[1]->h);
                 break;
            case 'P':
                 masked_stretch_blit(obiekty_4[2],ekran,0,0,obiekty_4[2]->w,obiekty_4[2]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_4[2]->w,skala*obiekty_4[2]->h);
                 break;
            case 'R':
                 masked_stretch_blit(obiekty_4[3],ekran,0,0,obiekty_4[3]->w,obiekty_4[3]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_4[3]->w,skala*obiekty_4[3]->h);
                 break;
            case 'Q':
                 masked_stretch_blit(obiekty_4[4],ekran,0,0,obiekty_4[4]->w,obiekty_4[4]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_4[4]->w,skala*obiekty_4[4]->h);
                 break;
            case 'S':
                 masked_stretch_blit(obiekty_4[5],ekran,0,0,obiekty_4[5]->w,obiekty_4[5]->h,obszar_gry_left+(j-poz_x-2)*skala*16,obszar_gry_top+(i-poz_y-2)*skala*14,skala*obiekty_4[5]->w,skala*obiekty_4[5]->h);
                 break;
            case 'T':
                 masked_stretch_blit(obiekty_4[6],ekran,0,0,obiekty_4[6]->w,obiekty_4[6]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[6]->w,skala*obiekty_4[6]->h);
                 break;
            case 'U':
                 masked_stretch_blit(obiekty_4[7],ekran,0,0,obiekty_4[7]->w,obiekty_4[7]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[7]->w,skala*obiekty_4[7]->h);
                 break;
            case 'W':
                 masked_stretch_blit(obiekty_4[8],ekran,0,0,obiekty_4[8]->w,obiekty_4[8]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[8]->w,skala*obiekty_4[8]->h);
                 break;
            case 'Z':
                 masked_stretch_blit(obiekty_4[9],ekran,0,0,obiekty_4[9]->w,obiekty_4[9]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[9]->w,skala*obiekty_4[9]->h);
                 break;
            case '#':
                 masked_stretch_blit(obiekty_4[10],ekran,0,0,obiekty_4[10]->w,obiekty_4[10]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[10]->w,skala*obiekty_4[10]->h);
                 break;
            case 'X':
                 masked_stretch_blit(obiekty_4[11],ekran,0,0,obiekty_4[11]->w,obiekty_4[11]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[11]->w,skala*obiekty_4[11]->h);
                 break;
            case 'Y':
                 masked_stretch_blit(obiekty_4[12],ekran,0,0,obiekty_4[12]->w,obiekty_4[12]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[12]->w,skala*obiekty_4[12]->h);
                 break;
            case '"':
                 masked_stretch_blit(obiekty_4[13],ekran,0,0,obiekty_4[13]->w,obiekty_4[13]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[13]->w,skala*obiekty_4[13]->h);
                 break;
            case '%':
                 masked_stretch_blit(obiekty_4[14],ekran,0,0,obiekty_4[14]->w,obiekty_4[14]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[14]->w,skala*obiekty_4[14]->h);
                 break;
            case '&':
                 masked_stretch_blit(obiekty_4[15],ekran,0,0,obiekty_4[15]->w,obiekty_4[15]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_4[15]->w,skala*obiekty_4[15]->h);
                 break;
                 
                 //SZOSTA ZAKLADKA
            case 'e':
                 masked_stretch_blit(obiekty_5[0],ekran,0,0,obiekty_5[0]->w,obiekty_5[0]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_5[0]->w,skala*obiekty_5[0]->h);
                 break;
            case 'f':
                 masked_stretch_blit(obiekty_5[1],ekran,0,0,obiekty_5[1]->w,obiekty_5[1]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_5[1]->w,skala*obiekty_5[1]->h);
                 break;
            case 'g':
                 masked_stretch_blit(obiekty_5[2],ekran,0,0,obiekty_5[2]->w,obiekty_5[2]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_5[2]->w,skala*obiekty_5[2]->h);
                 break;
            case 'h':
                 masked_stretch_blit(obiekty_5[3],ekran,0,0,obiekty_5[3]->w,obiekty_5[3]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_5[3]->w,skala*obiekty_5[3]->h);
                 break;
            case 'i':
                 masked_stretch_blit(obiekty_5[4],ekran,0,0,obiekty_5[4]->w,obiekty_5[4]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_5[4]->w,skala*obiekty_5[4]->h);
                 break;
            case 'k':
                 masked_stretch_blit(obiekty_5[5],ekran,0,0,obiekty_5[5]->w,obiekty_5[5]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_5[5]->w,skala*obiekty_5[5]->h);
                 break;
            case 'l':
                 masked_stretch_blit(obiekty_5[6],ekran,0,0,obiekty_5[6]->w,obiekty_5[6]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_5[6]->w,skala*obiekty_5[6]->h);
                 break;
            case 'o':
                 masked_stretch_blit(obiekty_5[7],ekran,0,0,obiekty_5[7]->w,obiekty_5[7]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_5[7]->w,skala*obiekty_5[7]->h);
                 break;
            case 'p':
                 masked_stretch_blit(obiekty_5[8],ekran,0,0,obiekty_5[8]->w,obiekty_5[8]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_5[8]->w,skala*obiekty_5[8]->h);
                 break;
                 
                 //SIODMA ZAKLADKA
            case '/':
                 masked_stretch_blit(obiekty_6[0],ekran,0,0,obiekty_6[0]->w,obiekty_6[0]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_6[0]->w,skala*obiekty_6[0]->h);
                 break;
            case '.':
                 masked_stretch_blit(obiekty_6[1],ekran,0,0,obiekty_6[1]->w,obiekty_6[1]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_6[1]->w,skala*obiekty_6[1]->h);
                 break;
            case '^':
                 masked_stretch_blit(obiekty_6[2],ekran,0,0,obiekty_6[2]->w,obiekty_6[2]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_6[2]->w,skala*obiekty_6[2]->h);
                 break;
            case '*':
                 masked_stretch_blit(obiekty_6[3],ekran,0,0,obiekty_6[3]->w,obiekty_6[3]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_6[3]->w,skala*obiekty_6[3]->h);
                 break;
            case '-':
                 masked_stretch_blit(obiekty_6[4],ekran,0,0,obiekty_6[4]->w,obiekty_6[4]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_6[4]->w,skala*obiekty_6[4]->h);
                 break;
            case '+':
                 masked_stretch_blit(obiekty_6[5],ekran,0,0,obiekty_6[5]->w,obiekty_6[5]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_6[5]->w,skala*obiekty_6[5]->h);
                 break;
            case '?':
                 masked_stretch_blit(obiekty_6[6],ekran,0,0,obiekty_6[6]->w,obiekty_6[6]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_6[6]->w,skala*obiekty_6[6]->h);
                 break;
            case '=':
                 masked_stretch_blit(obiekty_6[7],ekran,0,0,obiekty_6[7]->w,obiekty_6[7]->h,obszar_gry_left+(j-poz_x)*skala*16,obszar_gry_top+(i-poz_y)*skala*14,skala*obiekty_6[7]->w,skala*obiekty_6[7]->h);
                 break;

     }
    }
  }
}
//void masked_stretch_blit(BITMAP *source, BITMAP *dest, int source_x, source_y, source_w, source_h,
                                                             //int dest_x, dest_y, dest_w, dest_h);

//      void wyswietl_mapke(BITMAP* ekran);
void Obszar_edycji::ustaw_siatke(void){
     ++czy_siatka %= 4;
}
void Obszar_edycji::ustaw_skale(void){
     ++skala %= 4;
     if (!skala) skala++;
}
void Obszar_edycji::przesun_lewo(void){
     obszar_gry_left = OBSZAR_GRY_LEFT;    //przywraca poczatkowy sposob wyswietlania (po tym jak doszlismy do prawej strony obszaru mapki
     --poz_x;
     if (poz_x<0) poz_x = 0;
     else poz_x %= szer;
}
void Obszar_edycji::przesun_prawo(void){
     ++poz_x;
     switch (skala) {
           case 1:
                if (rozdzielczosc == 0) {
                    if (poz_x > szer - 42) {                 //42 -> 41 + 4px tyle pol jest wyswietlanych przy tej rozdz i skali na ekranie 
                              poz_x--;
                              obszar_gry_left = 8;      //przesuwamy obszar rysowanej mapki tak, by prawa krawedz ostatniego pola pokrywala sie z obszar wdzialnym edytowanej mapy
                              }
                    }
                else {////////////////////////uzupelnic dla 1024
                     }
                break;
           case 2:
                if (rozdzielczosc == 0) {
                    if (poz_x > szer - 21) {                 //42 -> 20 + 20px
                              poz_x--;
                              obszar_gry_left = 8;      // przesuwamy obszar rysowanej mapki tak, by prawa krawedz ostatniego pola pokrywala sie z obszar wdzialnym edytowanej mapy
                              }
                }
                else {////////////////////////uzupelnic dla 1024
                     }
                break;
           case 3:
                if (rozdzielczosc == 0) {
                    if (poz_x > szer - 14) {                 
                              poz_x--;
                              obszar_gry_left = 8;      //(48-35) przesuwamy obszar rysowanej mapki tak, by prawa krawedz ostatniego pola pokrywala sie z obszar wdzialnym edytowanej mapy
                              }
                }
                else {////////////////////////uzupelnic dla 1024
                     }
                break;
     }
//     ++poz_x %= szer;

 //     if (poz_x == szer) poz_x--;
//     poz_x %= szer;
 //     if (rozdzielczosc == 0 && skala == 1 && poz_x == szer-42) obszar_gry_left = 8; 
}
void Obszar_edycji::przesun_gora(void){
     obszar_gry_top = OBSZAR_GRY_TOP;    //przywraca poczatkowy sposob wyswietlania (po tym jak doszlismy do dolnej strony obszaru mapki
     --poz_y;
     if (poz_y<0) poz_y = 0;
}
void Obszar_edycji::przesun_dol(void){
//     ++poz_y %= wys;
     ++poz_y;
     switch (skala) {
           case 1:
                if (rozdzielczosc == 0) {
                    if (poz_y > wys - 40) {                 
                              poz_y--;
                              }
                }
                else {////////////////////////uzupelnic dla 1024
                     }
                break;
           case 2:
                if (rozdzielczosc == 0) {
                    if (poz_y > wys - 20) {                 
                              poz_y--;
                              }
                }
                else {////////////////////////uzupelnic dla 1024
                     }
                break;
           case 3:
                if (rozdzielczosc == 0) {
                    if (poz_y > wys - 14) {                 
                              poz_y--;
                              obszar_gry_top = -8;
                              }
                }
                else {////////////////////////uzupelnic dla 1024
                     }
                break;
     }
     
}

int Obszar_edycji::wskaz_pole(int poz_kursora_x, int poz_kursora_y){
     int nr_pola_x, nr_pola_y;
     nr_pola_x = (poz_kursora_x - obszar_gry_left) / (16*skala) + poz_x;
     nr_pola_y = (poz_kursora_y - obszar_gry_top) / (14*skala) + poz_y;
     return (nr_pola_y * szer + nr_pola_x);
}

void Obszar_edycji::wyswietl_maly_prostokat(BITMAP* ekran, int nr_pola){
     masked_stretch_blit(prostokat_maly,ekran,0,0,16, 14, (nr_pola % szer - poz_x)*16*skala + obszar_gry_left, (nr_pola / szer - poz_y)*14*skala + obszar_gry_top, 16*skala, 14*skala);
}

void Obszar_edycji::wpisz_do_matrycy(char literka, int x, int y){
     matryca[y][x] = literka;
}

int Obszar_edycji::szer_mapy(void){
    return szer;
}

int Obszar_edycji::wys_mapy(void){
    return wys;
}

void Obszar_edycji::wyswietl_mape(BITMAP* ekran){
  if (czy_wlaczona_mapa) {
   rectfill(mapa, 0, 0, mapa->w, mapa->h, kolor_ziel_jasny);                              //zielony podklad dla mapy    
   for (int i=0; i<(wys); i++) {
     for (int j=0; j<(szer); j++) {
         switch (matryca[i][j]) {
//            case ' ':
//                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
//                 break;
            case 'q':
                 _putpixel16(mapa, j, i, kolor_braz_jasny);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case '�':
                 _putpixel16(mapa, j, i, kolor_szar);
                 break;
            case 's':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 't':
                 _putpixel16(mapa, j, i, kolor_braz_sredni);
                 break;
                 //DRUGA ZAKLADKA
            case '2':
                 _putpixel16(mapa, j, i, kolor_braz_sredni);
                 break;
            case '5':
                 _putpixel16(mapa, j, i, kolor_braz_sredni);
                 break;
            case '1':
                 _putpixel16(mapa, j, i, kolor_braz_sredni);
                 break;
            case '3':
                 _putpixel16(mapa, j, i, kolor_braz_sredni);
                 break;
            case '4':
                 _putpixel16(mapa, j, i, kolor_braz_sredni);
                 break;
            case '6':
                 _putpixel16(mapa, j, i, kolor_braz_sredni);
                 break;
            case '7':
                 _putpixel16(mapa, j, i, kolor_braz_sredni);
                 break;
            case '8':
                 _putpixel16(mapa, j, i, kolor_braz_sredni);
                 break;
            case 'w':
                 _putpixel16(mapa, j, i, kolor_nieb);
                 break;
                 //TRZECIA ZAKLADKA
            case 'A':
                 _putpixel16(mapa, j, i, kolor_ziel_ciemny);
                 break;
            case 'B':
                 _putpixel16(mapa, j, i, kolor_ziel_ciemny);
                 break;
            case 'C':
                 _putpixel16(mapa, j, i, kolor_ziel_ciemny);
                 break;
            case 'D':
                 _putpixel16(mapa, j, i, kolor_ziel_ciemny);
                 break;
            case 'E':
                 _putpixel16(mapa, j, i, kolor_ziel_ciemny);
                 break;
            case 'F':
                 _putpixel16(mapa, j, i, kolor_ziel_ciemny);
                 break;
            case 'G':
                 _putpixel16(mapa, j, i, kolor_ziel_ciemny);
                 break;
            case 'a':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'b':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'c':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'j':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'd':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'm':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'n':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
                 //CZWARTA ZAKLADKA
            case 'H':
                 _putpixel16(mapa, j-2, i-2, kolor_bial);
                 _putpixel16(mapa, j-1, i-2, kolor_bial);
                 _putpixel16(mapa, j, i-2, kolor_bial);
                 _putpixel16(mapa, j-2, i-1, kolor_bial);
                 _putpixel16(mapa, j-1, i-1, kolor_bial);
                 _putpixel16(mapa, j, i-1, kolor_bial);
                 _putpixel16(mapa, j-2, i, kolor_bial);
                 _putpixel16(mapa, j-1, i, kolor_bial);
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case 'I':
                 _putpixel16(mapa, j-2, i-2, kolor_bial);
                 _putpixel16(mapa, j-1, i-2, kolor_bial);
                 _putpixel16(mapa, j, i-2, kolor_bial);
                 _putpixel16(mapa, j-2, i-1, kolor_bial);
                 _putpixel16(mapa, j-1, i-1, kolor_bial);
                 _putpixel16(mapa, j, i-1, kolor_bial);
                 _putpixel16(mapa, j-2, i, kolor_bial);
                 _putpixel16(mapa, j-1, i, kolor_bial);
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case 'J':
                 _putpixel16(mapa, j-2, i-2, kolor_bial);
                 _putpixel16(mapa, j-1, i-2, kolor_bial);
                 _putpixel16(mapa, j, i-2, kolor_bial);
                 _putpixel16(mapa, j-2, i-1, kolor_bial);
                 _putpixel16(mapa, j-1, i-1, kolor_bial);
                 _putpixel16(mapa, j, i-1, kolor_bial);
                 _putpixel16(mapa, j-2, i, kolor_bial);
                 _putpixel16(mapa, j-1, i, kolor_bial);
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case 'L':
                 _putpixel16(mapa, j-2, i-2, kolor_bial);
                 _putpixel16(mapa, j-1, i-2, kolor_bial);
                 _putpixel16(mapa, j, i-2, kolor_bial);
                 _putpixel16(mapa, j-2, i-1, kolor_bial);
                 _putpixel16(mapa, j-1, i-1, kolor_bial);
                 _putpixel16(mapa, j, i-1, kolor_bial);
                 _putpixel16(mapa, j-2, i, kolor_bial);
                 _putpixel16(mapa, j-1, i, kolor_bial);
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case 'K':
                 _putpixel16(mapa, j-2, i-2, kolor_bial);
                 _putpixel16(mapa, j-1, i-2, kolor_bial);
                 _putpixel16(mapa, j, i-2, kolor_bial);
                 _putpixel16(mapa, j-2, i-1, kolor_bial);
                 _putpixel16(mapa, j-1, i-1, kolor_bial);
                 _putpixel16(mapa, j, i-1, kolor_bial);
                 _putpixel16(mapa, j-2, i, kolor_bial);
                 _putpixel16(mapa, j-1, i, kolor_bial);
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case 'M':
                 _putpixel16(mapa, j-2, i-2, kolor_bial);
                 _putpixel16(mapa, j-1, i-2, kolor_bial);
                 _putpixel16(mapa, j, i-2, kolor_bial);
                 _putpixel16(mapa, j-2, i-1, kolor_bial);
                 _putpixel16(mapa, j-1, i-1, kolor_bial);
                 _putpixel16(mapa, j, i-1, kolor_bial);
                 _putpixel16(mapa, j-2, i, kolor_bial);
                 _putpixel16(mapa, j-1, i, kolor_bial);
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case 'r':
                 _putpixel16(mapa, j, i, kolor_braz_ciemny);
                 break;
            case 'x':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case 'y':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case 'z':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case ':':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case ';':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case '9':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case '0':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case '<':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case '>':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;
            case ',':
                 _putpixel16(mapa, j, i, kolor_bial);
                 break;

                 //PIATA ZAKLADKA
            case 'N':
                 _putpixel16(mapa, j-2, i-2, kolor_czer);
                 _putpixel16(mapa, j-1, i-2, kolor_czer);
                 _putpixel16(mapa, j, i-2, kolor_czer);
                 _putpixel16(mapa, j-2, i-1, kolor_czer);
                 _putpixel16(mapa, j-1, i-1, kolor_czer);
                 _putpixel16(mapa, j, i-1, kolor_czer);
                 _putpixel16(mapa, j-2, i, kolor_czer);
                 _putpixel16(mapa, j-1, i, kolor_czer);
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'O':
                 _putpixel16(mapa, j-2, i-2, kolor_czer);
                 _putpixel16(mapa, j-1, i-2, kolor_czer);
                 _putpixel16(mapa, j, i-2, kolor_czer);
                 _putpixel16(mapa, j-2, i-1, kolor_czer);
                 _putpixel16(mapa, j-1, i-1, kolor_czer);
                 _putpixel16(mapa, j, i-1, kolor_czer);
                 _putpixel16(mapa, j-2, i, kolor_czer);
                 _putpixel16(mapa, j-1, i, kolor_czer);
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'P':
                 _putpixel16(mapa, j-2, i-2, kolor_czer);
                 _putpixel16(mapa, j-1, i-2, kolor_czer);
                 _putpixel16(mapa, j, i-2, kolor_czer);
                 _putpixel16(mapa, j-2, i-1, kolor_czer);
                 _putpixel16(mapa, j-1, i-1, kolor_czer);
                 _putpixel16(mapa, j, i-1, kolor_czer);
                 _putpixel16(mapa, j-2, i, kolor_czer);
                 _putpixel16(mapa, j-1, i, kolor_czer);
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'R':
                 _putpixel16(mapa, j-2, i-2, kolor_czer);
                 _putpixel16(mapa, j-1, i-2, kolor_czer);
                 _putpixel16(mapa, j, i-2, kolor_czer);
                 _putpixel16(mapa, j-2, i-1, kolor_czer);
                 _putpixel16(mapa, j-1, i-1, kolor_czer);
                 _putpixel16(mapa, j, i-1, kolor_czer);
                 _putpixel16(mapa, j-2, i, kolor_czer);
                 _putpixel16(mapa, j-1, i, kolor_czer);
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'Q':
                 _putpixel16(mapa, j-2, i-2, kolor_czer);
                 _putpixel16(mapa, j-1, i-2, kolor_czer);
                 _putpixel16(mapa, j, i-2, kolor_czer);
                 _putpixel16(mapa, j-2, i-1, kolor_czer);
                 _putpixel16(mapa, j-1, i-1, kolor_czer);
                 _putpixel16(mapa, j, i-1, kolor_czer);
                 _putpixel16(mapa, j-2, i, kolor_czer);
                 _putpixel16(mapa, j-1, i, kolor_czer);
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'S':
                 _putpixel16(mapa, j-2, i-2, kolor_czer);
                 _putpixel16(mapa, j-1, i-2, kolor_czer);
                 _putpixel16(mapa, j, i-2, kolor_czer);
                 _putpixel16(mapa, j-2, i-1, kolor_czer);
                 _putpixel16(mapa, j-1, i-1, kolor_czer);
                 _putpixel16(mapa, j, i-1, kolor_czer);
                 _putpixel16(mapa, j-2, i, kolor_czer);
                 _putpixel16(mapa, j-1, i, kolor_czer);
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'T':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'U':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'W':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'Z':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case '#':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'X':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case 'Y':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case '"':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case '%':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
            case '&':
                 _putpixel16(mapa, j, i, kolor_czer);
                 break;
                 
                 //SZOSTA ZAKLADKA
            case 'e':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'f':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'g':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'h':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'i':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'k':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'l':
                 _putpixel16(mapa, j, i, kolor_ziel_jasny);
                 break;
            case 'o':
                 _putpixel16(mapa, j, i, kolor_poma);
                 break;
            case 'p':
                 _putpixel16(mapa, j, i, kolor_poma);
                 break;
                 //SIODMA ZAKLADKA
            case '/':
                 _putpixel16(mapa, j, i, kolor_poma_ciemny);
                 break;
            case '.':
                 _putpixel16(mapa, j, i, kolor_poma_ciemny);
                 break;
            case '^':
                 _putpixel16(mapa, j, i, kolor_poma_ciemny);
                 break;
            case '*':
                 _putpixel16(mapa, j, i, kolor_poma_ciemny);
                 break;
            case '-':
                 _putpixel16(mapa, j, i, kolor_poma_ciemny);
                 break;
            case '+':
                 _putpixel16(mapa, j, i, kolor_poma_ciemny);
                 break;
            case '?':
                 _putpixel16(mapa, j, i, kolor_poma_ciemny);
                 break;
            case '=':
                 _putpixel16(mapa, j, i, kolor_poma_ciemny);
                 break;
                 }
                    
     }
   }

  //   rect(ekran, 20, 20, skala_mapy*64, skala_mapy*64, 0);
     rectfill(ekran, 20, 20, 20+skala_mapy*66, 20+skala_mapy*66, kolor_braz_jasny);               //obwodka mapki
     rect(mapa, poz_x, poz_y, poz_x+obwodka[2*(skala-1)], poz_y+obwodka[2*(skala-1)+1], kolor_bial);                              //zielony podklad dla mapy         
     stretch_blit(mapa,ekran,0,0,mapa->w,mapa->h,20+skala_mapy,20+skala_mapy,skala_mapy*mapa->w,skala_mapy*mapa->h);
  }
}

void Obszar_edycji::wlacz_mape(void){
     czy_wlaczona_mapa++;
     czy_wlaczona_mapa %= 2;
     
}

void Obszar_edycji::zmien_skale_mapy(void){
     skala_mapy++;
     skala_mapy = skala_mapy % 6;
     if (!skala_mapy) skala_mapy++;
}

void Obszar_edycji::zmien_mleko(void){
     mleko++;
     mleko %= 10;
}

void Obszar_edycji::zmien_czy_generowana_postac(void){
     czy_generowana_postac++;
     czy_generowana_postac %= 2;
}

void Obszar_edycji::zmien_typ_rozgrywki(void){
     typ_rozgrywki++;
     typ_rozgrywki %= 4;
}

void Obszar_edycji::zmien_rodzaj_zakonczenia(void){
     rodzaj_zakonczenia++;
     rodzaj_zakonczenia %= 3;
}

void Obszar_edycji::zmien_postac_kluczowa(void){
     postac_kluczowa++;
     postac_kluczowa %= 10;
}

void Obszar_edycji::zmien_liczba_chat(void){
     liczba_chat++;
     liczba_chat %= 21;
}

int Obszar_edycji::zwroc_rodzaj_zakonczenia(void){
    return (rodzaj_zakonczenia);
}

void Obszar_edycji::wyswietl_ustawienia_mapy(BITMAP* ekran){

      //okienko + naglowek
      rectfill(ekran, 200, 100, 600, 500, 0);
      masked_stretch_blit(pusty_przycisk,ekran,0,0,18,16, 200, 100, 400, 400);
      rectfill(ekran, 325, 105, 473, 121, 0);
      textout_centre(ekran, font, "USTAWIENIA MAPY", SCREEN_W/2, 110, 65000);

      //tekst
      masked_blit(pusty_przycisk,ekran,0,0,240,140,18,16);
      textout(ekran, font, "Ilosc mleka:", 270, 145, 65000);
      textout(ekran, font, intToChar(mleko), 375, 145, 65000);
      
      masked_blit(pusty_przycisk,ekran,0,0,240,170,18,16);
      textout(ekran, font, "Generowanie postaci:", 270, 175, 65000);
      switch (czy_generowana_postac) {
             case 0: 
                       textout(ekran, font, "nie", 440, 175, 65000);
                       break;
             case 1: 
                       textout(ekran, font, "tak", 440, 175, 65000);
                       break;
      }
      
      masked_blit(pusty_przycisk,ekran,0,0,240,200,18,16);
      textout(ekran, font, "Typ rozgrywki:", 270, 205, 65000);
      switch (typ_rozgrywki) {
             case 0: 
                       textout(ekran, font, "wioska", 390, 205, 65000);
                       break;
             case 1: 
                       textout(ekran, font, "atak", 390, 205, 65000);
                       break;
             case 2: 
                       textout(ekran, font, "stoja", 390, 205, 65000);
                       break;
             case 3: 
                       textout(ekran, font, "nic", 390, 205, 65000);
                       break;
      }

      masked_blit(pusty_przycisk,ekran,0,0,240,230,18,16);
      textout(ekran, font, "Rodzaj zakonczenia:", 270, 235, 65000);
      switch (rodzaj_zakonczenia) {
             case 0: 
                       textout(ekran, font, "zniszcz", 430, 235, 65000);
                       break;
             case 1: 
                       textout(ekran, font, "uratuj", 430, 235, 65000);
                       break;
             case 2: 
                       textout(ekran, font, "zbuduj", 430, 235, 65000);
                       break;
      }

      if (rodzaj_zakonczenia == 1) {  //cel misji: uratuj
            masked_blit(pusty_przycisk,ekran,0,0,240,260,18,16);
            textout(ekran, font, "Postac kluczowa:", 270, 265, 65000);
            switch (postac_kluczowa) {
                    case 0: 
                         textout(ekran, font, "krowa", 405, 265, 65000);
                         break;
                    case 1: 
                         textout(ekran, font, "drwal", 405, 265, 65000);
                         break;
                    case 2: 
                         textout(ekran, font, "mysliwy", 405, 265, 65000);
                         break;
                    case 3: 
                         textout(ekran, font, "kaplanka", 405, 265, 65000);
                         break;
                    case 4: 
                         textout(ekran, font, "kaplan", 405, 265, 65000);
                         break;
                    case 5: 
                         textout(ekran, font, "miecznik", 405, 265, 65000);
                         break;
                    case 6: 
                         textout(ekran, font, "wlocznik", 405, 265, 65000);
                         break;
                    case 7: 
                         textout(ekran, font, "rycerz", 405, 265, 65000);
                         break;
                    case 8: 
                         textout(ekran, font, "niedzwiedz", 405, 265, 65000);
                         break;
                    case 9: 
                         textout(ekran, font, "strzyga", 405, 265, 65000);
                         break;
            }
      }
      
      
      if (rodzaj_zakonczenia == 2) {//zbuduj ilestam chat
                  masked_blit(pusty_przycisk,ekran,0,0,240,260,18,16);
            textout(ekran, font, "Liczba chat do zbudowania:", 270, 265, 65000);
            textout(ekran, font, intToChar(liczba_chat), 490, 265, 65000);
      }

      switch (mleko) {
             case '0':
                       break;
      }

      textout_centre(ekran, font, "spacja --- powrot do edycji mapy", SCREEN_W/2, 455, 65000);
      
      //wskaznik pozycji kursora
      rectfill(ekran, 40, SCREEN_H-16, 110, SCREEN_H - 5, 55000);
      textout_centre(ekran, font, intToChar(mouse_x), 60, SCREEN_H-13, 10);
      textout_centre(ekran, font, intToChar(mouse_y), 60+30, SCREEN_H-13, 10);
      //wskaznik nr pola, nad ktorym jest kursor
      rectfill(ekran, 120, SCREEN_H-16, 170, SCREEN_H - 5, 55000);
      textout_centre(ekran, font, intToChar(wskaz_pole(mouse_x, mouse_y)), 145, SCREEN_H-13, 10);
}


//ZAPISYWANIE DO PLIKU
void Obszar_edycji::quick_save(void){
     quick = fopen("quick", "w");
     putc(0x0D, quick);      //wstawoa \n
     
     putc(0x21, quick); //wstawia !
     for (int i=0; i<wys+2; i++) putc(0x61, quick); //wstawia a
     putc(0x0D, quick);      //wstawia \n

     for (int i=0; i<(wys); i++) {
         putc(0x21, quick); //wstawia !
         putc(0x61, quick); //wstawia a
         for (int j=0; j<(szer); j++) {
             putc(matryca[i][j], quick);
         }
         putc(0x61, quick);      //wstawia a
         putc(0x0D, quick);      //wstawoa \n
     }

     putc(0x21, quick); //wstawia !
     for (int i=0; i<wys+2; i++) putc(0x61, quick); //wstawia caly wiersz a
     putc(0x0D, quick);putc(0x0D, quick);
     fclose(quick);
}

void Obszar_edycji::quick_load(void){
     char c;
     if (quick = fopen("quick", "r"))
     {

        while (fgetc(quick) != '!');
                

        //DOCELOWO MA DZIOALAC W TEN SPOSOB:
        for (int i=0; i<wys; i++) {
          while (fgetc(quick) != '!');      

          c = fgetc(quick);            //pominiecie pierwszego znaku

          for (int j=0; j<szer; j++) {              //zczytuje caly wiersz do wiersza matrycy
              matryca[i][j] = fgetc(quick);
          }
        }

        fclose(quick);
     }
}

void Obszar_edycji::load(int nr_misji){
     char c;
     FILE * plik;
     
     if (plik = fopen("LEVEL.DAT", "r")) {

       int i = 1;
     
       while ((c = fgetc(plik)) != '$' || i != nr_misji) if (c == '$') i++; //przechodzimy do wiersza z ustawieniami danej mapki
//       while (fgetc(plik) != '$');
       while (fgetc(plik) != '!'); //przechodzimy do "niewaznego" wiersza (z takimi samymi literkami)
  
       //tutaj zczytujemy     
          for (int i=0; i<wys; i++) {
            while (fgetc(plik) != '!');      

             c = fgetc(plik);            //pominiecie pierwszego znaku  

             for (int j=0; j<szer; j++) {              //zczytuje caly wiersz do wiersza matrycy
                 matryca[i][j] = fgetc(plik);
             }
          }
          
          fclose(plik);
          
     }//if
}




