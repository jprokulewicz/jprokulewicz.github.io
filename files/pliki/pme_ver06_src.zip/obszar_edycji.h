#include <allegro.h>
#include <stdio.h>
#include "mapka.h"

class Obszar_edycji {
      int szer;     //rozmiar edytowanej mapy
      int wys;
      char ** matryca;
      int poz_x;      //wspolrzedne segmentu wyswietlanego w lewym gornym rogu
      int poz_y;
      int czy_siatka;
      int skala;     //zoom, = 1, 2 lub 3
      int obszar_gry_top; //wspolrzedne ,od ktorych rysujemy obszar gry (w px)
      int obszar_gry_left;

      BITMAP* drzewo;
      BITMAP* trawa;
      BITMAP* square;      
      
      BITMAP* prostokat_maly;
      BITMAP* pusty_przycisk;

      BITMAP* obiekty_0[16];
      BITMAP* obiekty_1[9];
      BITMAP* obiekty_2[14];
      BITMAP* obiekty_3[17];      
      BITMAP* obiekty_4[16];      
      BITMAP* obiekty_5[9];
      BITMAP* obiekty_6[8];
      
//DO MAPY      
      int czy_wlaczona_mapa;
      int skala_mapy;
      BITMAP* mapa;
      int obwodka[6];
      
      int kolor_nieb;
      int kolor_czer;
      int kolor_braz_jasny;
      int kolor_braz_sredni;
      int kolor_braz_ciemny;
      int kolor_ziel_jasny;
      int kolor_ziel_ciemny;
      int kolor_poma;
      int kolor_poma_ciemny;
      int kolor_bial;
      int kolor_szar;
      int kolor_czar;
      
//ZAPISYWANIE DO PLIKU
      FILE * quick;
      
//USTAWIENIA MAPY
      int mleko;
      int czy_generowana_postac;
      int typ_rozgrywki;
      int rodzaj_zakonczenia;
      int postac_kluczowa;
      int liczba_chat;

      

public:
      Obszar_edycji(int wysokosc, int szerokosc);      
      void wyczysc_mapke(void);
      void wyswietl_mapke(BITMAP* ekran);
      void ustaw_siatke(void);
      void ustaw_skale(void);
      void przesun_lewo(void);
      void przesun_prawo(void);
      void przesun_gora(void);
      void przesun_dol(void);
      int wskaz_pole(int poz_kursora_x, int poz_kursora_y);
      void wyswietl_maly_prostokat(BITMAP* ekran, int nr_pola);
      void wpisz_do_matrycy(char literka, int x, int y);
      int szer_mapy(void);
      int wys_mapy(void);

//DO MAPY
      void wyswietl_mape(BITMAP* ekran);
      void wlacz_mape(void);
      void zmien_skale_mapy(void);

//ZAPISYWANIE DO PLIKU
      void quick_save(void);
      void quick_load(void);
      void load(int nr_misji);

//USTAWIENIA MAPY
      void zmien_mleko(void);
      void zmien_czy_generowana_postac(void);
      void zmien_typ_rozgrywki(void);
      void zmien_rodzaj_zakonczenia(void);
      void zmien_postac_kluczowa(void);
      void zmien_liczba_chat(void);
      int zwroc_rodzaj_zakonczenia(void);
      void wyswietl_ustawienia_mapy(BITMAP* ekran);


};



