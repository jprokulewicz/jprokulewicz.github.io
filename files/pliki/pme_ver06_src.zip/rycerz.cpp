class rycerz {
              
};
