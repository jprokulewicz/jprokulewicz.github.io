#include "tryb_grafiki.h"
#include <allegro.h>



Tryb_grafiki::Tryb_grafiki(int tryb_zadany, int w_oknie) {
       this->tryb_zadany = tryb_zadany;
       this->w_oknie = w_oknie;
       aktualizuj_tryb();
}

void Tryb_grafiki::aktualizuj_tryb(void) {
     if ( ((2*tryb_zadany)+w_oknie) != tryb_ustawiony ) {
       switch ((2*tryb_zadany)+w_oknie) {
         case 0 :
           set_gfx_mode(GFX_AUTODETECT, 800, 600, 0, 0);
           ekran_width = 800;
           ekran_height = 600;             
           tryb_ustawiony = 0;
           break;
         case 1 :
           set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0);
           ekran_width = 800;
           ekran_height = 600;             
           tryb_ustawiony = 1;           
           break;
         case 2 :
           set_gfx_mode(GFX_AUTODETECT, 1024, 768, 0, 0);              
           ekran_width = 1024;
           ekran_height = 768;             
           tryb_ustawiony = 2;           
           break;
         case 3 :
           set_gfx_mode(GFX_AUTODETECT_WINDOWED, 1024, 768, 0, 0);
           ekran_width = 1024;
           ekran_height = 768;             
           tryb_ustawiony = 3;
           break;
       }    
     }
}

void Tryb_grafiki::zmien_tryb(int tryb_zadany) {
     this->tryb_zadany = tryb_zadany;
     aktualizuj_tryb();
}

void Tryb_grafiki::zmien_tryb_nastepny(void) {
     tryb_zadany++;
     tryb_zadany %= 2;
     aktualizuj_tryb();
}


void Tryb_grafiki::zmien_tryb_okno(void){
     w_oknie++;
     w_oknie %= 2;
     aktualizuj_tryb();
}

int Tryb_grafiki::zwroc_ekran_width(void) {
     return this->ekran_width;
}

int Tryb_grafiki::zwroc_ekran_height(void) {
     return this->ekran_height;
}

int Tryb_grafiki::ustawiony_tryb(void) {
    return (tryb_ustawiony/2);
}


