class Tryb_grafiki {

int tryb_zadany;
int tryb_ustawiony;
int w_oknie;
int ekran_width;
int ekran_height;

public:
       Tryb_grafiki(int tryb_zadany, int w_oknie);       
       void aktualizuj_tryb(void);
       void zmien_tryb(int tryb_zadany);
       void zmien_tryb_nastepny(void);       
       void zmien_tryb_okno(void);
       int zwroc_ekran_width(void);       
       int zwroc_ekran_height(void);
       int ustawiony_tryb(void);
};


