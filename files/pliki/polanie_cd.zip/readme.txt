GRA "POLANIE CD", WERSJA OKROJONA
--------------------------------------

OPIS:
Aplikacja ta jest okrojon� wersj� gry POLANIE CD. Zawiera ona wszystkie misje, kt�re zosta�y zawarte przez tw�rc�w w p�ytowej wersji gry. Nie ma za� kilku rzeczy, kt�re do normalnej gry nie s� potrzebne, to znaczy wszelkich intr pocz�tkowych oraz intra ko�cowego. Brakuje te� muzyki, kt�r� autorzy zapisali na p�ycie w formie �cie�ki Audio. I to by by�o na tyle zmian.

SPOS�B INSTALACJI:
Ta wersja gry ukaza�a si� na p�ycie, kt�ra by�a potrzebna zar�wno do instalacji jak i p�niejszego u�ywania gry. Wersja ta zosta�a "spreparowana" w celu zmniejszenia obj�to�ci przez ni� zajmownej, co z kolei umo�liwi�oby �ci�gni�cie jej przez Internet. Przedstawi� Wam tutaj spos�b na zainstalowanie tej gry. Do jej uzywania nie b�dzie wymagana �adna p�yta. U�yte przeze mnie nazwy katalog�w i partycji s� tylko moimi propozycjami, dzia�aj�cymi w przypadku mojego komputera. Mo�ecie jed dowolnie zmienia�, je�eli tylko b�dzie to dla Was wygodniejsze.

Wszystkie niezb�dne czynno�ci wypunktowa�em poni�ej:

1. Tworzymy katalog o nazwie "Virtual" na dysku "D:". W tym katalogu tworzymy podkatalog "POLANIE".
2. Przegrywamy do niego ca�� zawarto�� pliku "polanie_cd.zip" (10 MB po rozpakowaniu).
3. Uruchamiamy "Tryb MS-DOS".
4. W linii polece� wpisujemy polecenie "SUBST G: D:\VIRTUAL\POLANIE", gdzie litera "G:" jest pierwsz� woln� liter� po ostatnim z CD-ROM�w. Przyk�adowo, je�eli Tw�j CD-ROM ma literk� "E:", to tutaj wpisujesz "F:"; natomiast fragment "D:\VIRTUAL\POLANIE" oznacza �cie�k� dost�pu do katalogu, w kt�rym znajduj� si� pliki przegrane w punkcie numer 2.
5. Uruchamiaj�c teraz "Eksplorator Windows" zauwa�ymy, �e "dosz�a" nam jedna partycja - w tym przypadku "G:" - o etykiecie identycznej z etykiet� partycji "D:".
6. Klikamy na literze "G:". Po prawej stronie pojawi nam si� lista plik�w zawartych w katalogu "D:\VIRTUAL\POLANIE". Uruchamiamy wi�c plik "Instaluj.exe" na dysku "G:" i instalujemy najzwyczajniej w �wiecie demo. Po poprawnym zainstalowaniu gry (na przyk�ad w katalogu "D:\GRY\POLANIE") uruchamiamy Setup (przygotowa�em dwa pliki ("_start.bat" oraz "_setup.bat"), kt�rych powiniene� u�ywa� do uruchamiania Setup'a oraz samej gry) i konfigurujemy kart� d�wi�kow� pami�taj�c o wy��czeniu muzyki, gdy� i tak nie b�dzie ona dost�pna bez p�yty. Mo�emy teraz uruchomi� bez kompaktu okrojon� wersj� POLANIE CD. Je�eli koniecznie chcemy mie� muzyk�, mo�emy w�o�y� dowoln� p�ytk� do czytnika i r�cznie w��czy� odtwarzanie utworu, tak samo jak by�my chcieli pos�ucha� muzyki.

Uwaga!
Po zrestartowaniu komputera utworzona poprzednio partycja "G:" zniknie i ta wersja gry Polanie CD nie b�dzie dzia�a�. Mo�emy j� odtworzy� uruchamiaj�c wcze�niej u�yte polecenie "SUBST G: D:\VIRTUAL\POLANIE". Proponuj� jednak u�atwi� sobie ca�� t� operacj� pisz�c plik wsadowy "start.bat", automatycznie tworz�cy now� "partycj�" i uruchamiaj�cy Polan. Taki w�a�nie plik zawar�em w pliku, kt�ry �ci�gn��e�. Nale�y go skopiowa� do katalogu z Polanami i od tej pory zawsze odpala� nim gr�. Zauwa�, �e plik ten zosta� stworzony w postaci stosownej dla mojego przypadku. Je�eli wi�c z jakich� przyczyn zmieni�e� zaproponowane przez mnie nazwy katalog�w czy partycji, to musisz r�cznie wyedytowa� plik i zmieni� stosowne fragmenty.

To chyba wszystkie informacje potrzebne do skutecznego u�ywania tej wersji POLANIE CD. Je�eli masz jeszcze jakie� w�tpliwo�ci lub czego� nie rozumiesz, napisz. S�u�� pomoc�!

--------------------------------------
DOKUMENTACJ� OPRACOWA�:
Janusz "Swoosh" Prokulewicz
jprokulewicz@poczta.onet.pl
www.polanie.prv.pl