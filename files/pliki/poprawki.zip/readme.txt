POPRAWKI DO GRY "POLANIE CD", VER.4.27
-------------------------------------------

SPOS�B INSTALACJI:
Rozpakuj pliki "polanie.exe" oraz "setup.exe" do katalogu g��wnego gry POLANIE CD. I... tyle. Wa�ne jest, aby uaktualnienia dokona� bezpo�rednio po zainstalowaniu gry, jeszcze przed jej pierwszym uruchomieniem.

ZMIANY W TEJ WERSJI:
- rozwi�zanie problem�w z odtwarzaniem d�wi�k�w na niekt�rych kartach d�wi�kowych (g��wnie tych starszych),
- zlikwidowanie b��du powoduj�cego, �e w niekt�rych misjach jednostki wychodz� poza obszar misji,
- naprawienie kilku innych drobniejszych b��d�w gry.


-------------------------------------------
DOKUMENTACJ� OPRACOWA�:
Janusz "Swoosh" Prokulewicz
jprokulewicz@poczta.onet.pl
www.polanie.prv.pl