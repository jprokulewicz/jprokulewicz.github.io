VICTORY - PE�NA NIEMIECKOJ�ZYCZNA WERSJA GRY "POLANIE" 
-----------------------------------------------------------

OPIS:
Zapraszam do zapoznania si� z niemieck� edycj� polskiej gry "Polanie", pod nazw� "Victory". Zosta�a ona opracowana na bazie dysketkowej wersji "Polan". Mimo, �e zajmuje ona znacznie mniej ni� wersja polska, to jej zawarto�� jest praktycznie taka sama. Nie ma tylko, ze zrozumia�ych wzgl�d�w zreszt�, pocz�tkowego intra. Wi�cej informacji o tej wersji znajdziesz na mojej witrynie.

SPOS�B INSTALACJI:
Wystarczy tylko uruchomi� plik "Install.bat" i poda� �cie�k� dost�pu do katalogu, w kt�rym ma zosta� zainstalowana gra.

W razie jakichkolwiek k�opot�w prosz� si� zg�osi� pod ni�ej wskazany adres. Ch�tnie pomog�!


-----------------------------------------------------------
DOKUMENTACJ� OPRACOWA�:
Janusz "Swoosh" Prokulewicz
jprokulewicz@poczta.onet.pl
www.polanie.prv.pl